
PATCH_LIB("libpatrons.so", "0xD08C64", "28 26 24 3E 21 44 4D 29 8C 83 A5 39 ED"); // bytes_strength=2600 offset_strength=96
PATCH_LIB("libpatrons.so", "0x7C6B19", "D3 05 0A 8A 22 57 33 70 2C"); // bytes_strength=1800 offset_strength=91
PATCH_LIB("libpatrons.so", "0xD8C1CC", "EE 80 0D BC E2 09 46 6A 7F F9 61 99 24 FE"); // bytes_strength=2800 offset_strength=93
PATCH_LIB("libpatrons.so", "0xB4F2FD", "73 21 1C 0F 98 65 5B DD 44"); // bytes_strength=1800 offset_strength=100
PATCH_LIB("libpatrons.so", "0xAA5254", "6F 4B 27 8C 0B E9 4D 2E 97 3C 99 88 49 A9"); // bytes_strength=2800 offset_strength=91
PATCH_LIB("libpatrons.so", "0x8096D5", "65 AE 0C 66 E8 CA B1 97 51 3C"); // bytes_strength=2000 offset_strength=90
PATCH_LIB("libpatrons.so", "0x90EBBF", "57 A4 E6 F6 E8 05 FD 6E 31 B6 E3 E7 AF 12 9B"); // bytes_strength=3000 offset_strength=92
PATCH_LIB("libpatrons.so", "0x34E624", "85 6B BE 99 6E 35 CD 42 32 7A CB 5F"); // bytes_strength=2400 offset_strength=99
PATCH_LIB("libpatrons.so", "0x325B2C", "FB FF 45 15 7C 06 05 B7 58 32 AC 97 12 46 F8 C1"); // bytes_strength=3200 offset_strength=95
PATCH_LIB("libpatrons.so", "0xB9EA54", "F3 F6 BA BA 07 C7 11 66 E2 73 1D 11 11 9D 67 B9"); // bytes_strength=3200 offset_strength=97
PATCH_LIB("libpatrons.so", "0x8E61F8", "9B 15 39 ED 4D 1E 1E A3 D1 73 05 E8 23 8A ED 2F"); // bytes_strength=3200 offset_strength=97
PATCH_LIB("libpatrons.so", "0xBE9B5B", "49 09 DC B1 C4 1E 07 AB DF A3 32 0C"); // bytes_strength=2400 offset_strength=99
PATCH_LIB("libpatrons.so", "0x47F928", "89 6E 75 08 08 CA 40 B1 D7"); // bytes_strength=1800 offset_strength=95
PATCH_LIB("libpatrons.so", "0x9A7032", "B3 F2 94 02 79 1B EB 5F 28 F8 F3 37"); // bytes_strength=2400 offset_strength=99
PATCH_LIB("libpatrons.so", "0x2E32BA", "56 7E 86 ED A3 64 C8 FD"); // bytes_strength=1600 offset_strength=99
PATCH_LIB("libpatrons.so", "0x9B5735", "AC FC CF 7E 7C C1 61 94 43 C8 06"); // bytes_strength=2200 offset_strength=98
PATCH_LIB("libpatrons.so", "0x69A12C", "E8 F3 5B 81 82 CB 95 2C EC EE 8B 4B CD"); // bytes_strength=2600 offset_strength=96
PATCH_LIB("libpatrons.so", "0xC92756", "5C 0E AC 1C 74 CA 69 2B 74 96 D8"); // bytes_strength=2200 offset_strength=99
PATCH_LIB("libpatrons.so", "0xBE252A", "BA AB 08 56 1D BA 53 31 4A 89"); // bytes_strength=2000 offset_strength=95
PATCH_LIB("libpatrons.so", "0xB1B5AE", "94 52 77 E8 98 8B 61 C5 DC E9 55 E1 A3 67"); // bytes_strength=2800 offset_strength=92
PATCH_LIB("libpatrons.so", "0x33E973", "07 1C 6E 1B 93 76 B1 7F 51 1A 93 4F F9"); // bytes_strength=2600 offset_strength=92
PATCH_LIB("libpatrons.so", "0x8E768A", "5F 6F B2 7E 6E BA 60 0B 46 C8 E0 8B F9"); // bytes_strength=2600 offset_strength=92
PATCH_LIB("libpatrons.so", "0x7CABB9", "44 33 EA 1A 9F D8 50 DA 94 B4"); // bytes_strength=2000 offset_strength=96
PATCH_LIB("libpatrons.so", "0xA9DCE0", "4F 14 D8 E4 36 AC 4D 33 54 AD 65"); // bytes_strength=2200 offset_strength=91
PATCH_LIB("libpatrons.so", "0xB85B75", "B7 BA 1C D1 7A E3 DD 12 6D 73 64 D0 0C 26 5C"); // bytes_strength=3000 offset_strength=93
PATCH_LIB("libpatrons.so", "0xBC6F65", "39 88 F7 86 53 F0 51 72"); // bytes_strength=1600 offset_strength=99
PATCH_LIB("libpatrons.so", "0xDC03C6", "93 05 3A E6 A2 FA 20 93 7D EE 35"); // bytes_strength=2200 offset_strength=92
PATCH_LIB("libpatrons.so", "0x3D956D", "C9 85 59 3B F0 4A B4 BB 39 EC AC A5 E4 D0 00 F1"); // bytes_strength=3200 offset_strength=97
PATCH_LIB("libpatrons.so", "0xFC1894", "41 76 40 A3 AB 8B 7E AF 94 65 95 AA 1A AF C3"); // bytes_strength=3000 offset_strength=99
PATCH_LIB("libpatrons.so", "0x7BB014", "FF 63 05 DE B9 6B B1 A6 36 99 27 90 93 C1"); // bytes_strength=2800 offset_strength=98
PATCH_LIB("libpatrons.so", "0x5A9774", "39 6D 3E 60 D3 F9 64 65 B9 A0"); // bytes_strength=2000 offset_strength=95
PATCH_LIB("libpatrons.so", "0x8C9333", "3B 0A 29 7B DC 64 0D 88"); // bytes_strength=1600 offset_strength=95
PATCH_LIB("libpatrons.so", "0x534D5E", "26 66 95 BB F4 76 F1 A6"); // bytes_strength=1600 offset_strength=90
PATCH_LIB("libpatrons.so", "0x2C9EF8", "3E F5 CC 6E 67 16 58 71 E5 45 1E 44"); // bytes_strength=2400 offset_strength=94
PATCH_LIB("libpatrons.so", "0xF3FBED", "6E E4 D0 60 B0 A5 29 9C 45 B6"); // bytes_strength=2000 offset_strength=90
PATCH_LIB("libpatrons.so", "0x5B7D90", "84 33 40 5E 61 67 BF 94"); // bytes_strength=1600 offset_strength=92
PATCH_LIB("libpatrons.so", "0x903D26", "F7 5C A4 E0 F7 E7 D7 A3 2F"); // bytes_strength=1800 offset_strength=94
PATCH_LIB("libpatrons.so", "0xC69E43", "DD E2 2E 9B C9 1A 36 96 B2 CA EE"); // bytes_strength=2200 offset_strength=95
PATCH_LIB("libpatrons.so", "0xFE037F", "94 42 33 75 7C 37 F4 E1 79 9C 39 7A C2"); // bytes_strength=2600 offset_strength=99
PATCH_LIB("libpatrons.so", "0x921CF6", "9D FA B4 E7 37 0F 51 C6 33 D6"); // bytes_strength=2000 offset_strength=92
PATCH_LIB("libpatrons.so", "0x902D14", "ED 28 88 7A 45 50 45 65 45 FB CD"); // bytes_strength=2200 offset_strength=97
PATCH_LIB("libpatrons.so", "0x93C7D9", "16 BC 35 EF 7D FA 79 07 B0 E2 AC 8F C6 3D 3E"); // bytes_strength=3000 offset_strength=95
PATCH_LIB("libpatrons.so", "0xE6E9EA", "10 04 5F 37 F4 59 C9 65 79 B0 CF 21"); // bytes_strength=2400 offset_strength=94
PATCH_LIB("libpatrons.so", "0xD9CB6F", "2A 5A 36 A0 71 D8 A5 D1 59 59 08 2F 68 F9 EF 04"); // bytes_strength=3200 offset_strength=94
PATCH_LIB("libpatrons.so", "0x9C34F5", "4F 90 7B 32 F1 C9 E6 29 A2 4B F7 FA A8"); // bytes_strength=2600 offset_strength=93
PATCH_LIB("libpatrons.so", "0xD81A1C", "A8 13 95 9F 2B 22 89 E0 6F 35 1C"); // bytes_strength=2200 offset_strength=100
PATCH_LIB("libpatrons.so", "0x184B88", "EF F6 96 60 CD 3B F3 3C"); // bytes_strength=1600 offset_strength=98
PATCH_LIB("libpatrons.so", "0xA6A0BB", "F9 2E 21 59 20 14 96 40 59 67"); // bytes_strength=2000 offset_strength=96
PATCH_LIB("libpatrons.so", "0xA503E9", "7A 41 98 26 0E 53 B6 C9 9A EF 3D C2 22 61 BB"); // bytes_strength=3000 offset_strength=94
PATCH_LIB("libpatrons.so", "0x8B7D6F", "AA F7 53 70 A5 DA 26 DD B7"); // bytes_strength=1800 offset_strength=97
PATCH_LIB("libpatrons.so", "0xB29861", "D5 17 19 97 FC 96 DB 3A 5E A3 49"); // bytes_strength=2200 offset_strength=91
PATCH_LIB("libpatrons.so", "0xB2F252", "2F AF 57 6D 0F 0D EE 7D BE"); // bytes_strength=1800 offset_strength=100
PATCH_LIB("libpatrons.so", "0xB4D271", "04 A8 8D 7D 46 C6 3A 55 11 3F 9A DF B8 08 73"); // bytes_strength=3000 offset_strength=90
PATCH_LIB("libpatrons.so", "0x2911D9", "B5 A0 1A DF BE 4C B4 94 22 63 66 77 68"); // bytes_strength=2600 offset_strength=96
PATCH_LIB("libpatrons.so", "0x63295E", "BF AB C1 48 1A 2E 4B 9B 5A 86 6B DB 23 D5"); // bytes_strength=2800 offset_strength=97
PATCH_LIB("libpatrons.so", "0x217919", "D5 F9 1D E8 AB 30 D4 2C 5C 38 B9 07 BB C7 C8"); // bytes_strength=3000 offset_strength=94
PATCH_LIB("libpatrons.so", "0x2F014F", "D1 06 A1 C3 3A 2A 61 3C 6A 5E"); // bytes_strength=2000 offset_strength=99
PATCH_LIB("libpatrons.so", "0x20DCE1", "AD DA 40 4E D1 BB 83 52 83 88 CA"); // bytes_strength=2200 offset_strength=99
PATCH_LIB("libpatrons.so", "0x4477B6", "1B 32 42 C1 92 2E 1C 0A 3F 2D 68 AC C2 31 36 BA"); // bytes_strength=3200 offset_strength=90
PATCH_LIB("libpatrons.so", "0x1C33D7", "C8 65 FB 59 04 16 09 50 75"); // bytes_strength=1800 offset_strength=90
PATCH_LIB("libpatrons.so", "0xE1BD1C", "F5 08 CB 74 6B 7B EC 14 C1 8B A0"); // bytes_strength=2200 offset_strength=97
PATCH_LIB("libpatrons.so", "0x422793", "3C EA 8D 93 9E 77 BC DA 2F 73 4B A0 4B 1F 85"); // bytes_strength=3000 offset_strength=95
PATCH_LIB("libpatrons.so", "0x926F53", "B4 22 D1 3A AF F9 1F 49 DF 10 06 56 0D"); // bytes_strength=2600 offset_strength=90
PATCH_LIB("libpatrons.so", "0xA09C7C", "4C AE D2 4D 6A 43 FF 4F 97 E3"); // bytes_strength=2000 offset_strength=90
PATCH_LIB("libpatrons.so", "0x689D74", "9B 76 57 7E 97 C3 F7 D4"); // bytes_strength=1600 offset_strength=94
PATCH_LIB("libpatrons.so", "0xB4F9D3", "F7 48 DD 87 C4 77 1E 4E 5E F9"); // bytes_strength=2000 offset_strength=92
PATCH_LIB("libpatrons.so", "0x902755", "E1 D3 5C F5 D7 5F 08 FA A2 1F 5B E6 5E 08 BD"); // bytes_strength=3000 offset_strength=92
PATCH_LIB("libpatrons.so", "0x390D8B", "31 F8 33 74 95 77 E7 21 84 39 86 3E 03 41 F7"); // bytes_strength=3000 offset_strength=99
PATCH_LIB("libpatrons.so", "0x202EB2", "C2 40 33 11 FA 46 53 E7 9C B8 67 49 42"); // bytes_strength=2600 offset_strength=97
PATCH_LIB("libpatrons.so", "0xDE96D4", "C5 A2 49 9B 25 FB D7 67 4F 00 2E 61 A0 30 85 DC"); // bytes_strength=3200 offset_strength=97
PATCH_LIB("libpatrons.so", "0xFA1FD0", "42 FC 93 E2 73 09 BC 70 FC D6 16 DD CA A0"); // bytes_strength=2800 offset_strength=98
PATCH_LIB("libpatrons.so", "0x6BB172", "52 50 AB 8F 1E 02 A5 E4 79"); // bytes_strength=1800 offset_strength=98
PATCH_LIB("libpatrons.so", "0x59919F", "A6 1C D4 53 32 78 29 F9 B3 88 AE 64 97 91"); // bytes_strength=2800 offset_strength=100
PATCH_LIB("libpatrons.so", "0xFFC8DC", "50 E6 02 47 28 7D E3 7C AA 17 04 94 54"); // bytes_strength=2600 offset_strength=100
PATCH_LIB("libpatrons.so", "0x11518D", "45 77 9B 3C EF 46 2A 32 36"); // bytes_strength=1800 offset_strength=96
PATCH_LIB("libpatrons.so", "0xF3EC89", "F5 40 E7 26 84 54 03 25 C0"); // bytes_strength=1800 offset_strength=91
PATCH_LIB("libpatrons.so", "0x50F91F", "7A F3 62 17 4B 26 5D BE 04 BA 49 8C 32 34 E0 2E"); // bytes_strength=3200 offset_strength=91
PATCH_LIB("libpatrons.so", "0x33F207", "3A FC E1 2F 1D BF C1 DB 44 BD 2F 56 44 78 AC 9C"); // bytes_strength=3200 offset_strength=92
PATCH_LIB("libpatrons.so", "0x6B35FE", "5C 29 11 D4 D4 80 A9 A8 F8"); // bytes_strength=1800 offset_strength=99
PATCH_LIB("libpatrons.so", "0xF36202", "0F 66 2D FF 1C 79 D1 CE"); // bytes_strength=1600 offset_strength=92
PATCH_LIB("libpatrons.so", "0x607C24", "57 08 24 0B 9C 0D D1 2B BC 43 86 80 96 CC E4"); // bytes_strength=3000 offset_strength=92
PATCH_LIB("libpatrons.so", "0x91FA6C", "13 0C F0 91 20 92 56 61 07 D2 C6 24 10"); // bytes_strength=2600 offset_strength=99
PATCH_LIB("libpatrons.so", "0x2EC4CF", "88 25 43 9A 4D DA 31 7F FF BF 76 14"); // bytes_strength=2400 offset_strength=92
PATCH_LIB("libpatrons.so", "0xF2E743", "66 2D 84 F6 30 37 FC E8 F3 A7 A9 D9 19"); // bytes_strength=2600 offset_strength=93
PATCH_LIB("libpatrons.so", "0x4E6A81", "A1 B0 39 A0 66 A4 E7 76 C5 61 F1 76 6B CB EB FA"); // bytes_strength=3200 offset_strength=100
PATCH_LIB("libpatrons.so", "0x8D8F86", "AA 24 60 02 AC 13 70 37 32 88 B5 63 B0 52 AE"); // bytes_strength=3000 offset_strength=93
PATCH_LIB("libpatrons.so", "0x1EE9DF", "FC 98 DF 1C 98 8D AE B1 3C D5 EE F1 FE 34 B6 56"); // bytes_strength=3200 offset_strength=96
PATCH_LIB("libpatrons.so", "0x8C7E40", "9B AC 90 28 BF D1 59 B6 5A 8A"); // bytes_strength=2000 offset_strength=98
PATCH_LIB("libpatrons.so", "0x47B36E", "0A AA 54 93 3C 39 0B 81 D5 3D F0"); // bytes_strength=2200 offset_strength=91
PATCH_LIB("libpatrons.so", "0x9E6AEB", "45 6B F9 4B D0 2A C4 53 D6"); // bytes_strength=1800 offset_strength=96
PATCH_LIB("libpatrons.so", "0x8FBC4A", "EF B7 B9 C6 05 73 4C B1 45 F3 47 AE"); // bytes_strength=2400 offset_strength=90
PATCH_LIB("libpatrons.so", "0x4DAEE4", "C4 41 98 F4 C8 BA 55 DD AA CD 7B 9F"); // bytes_strength=2400 offset_strength=92
PATCH_LIB("libpatrons.so", "0x5AC393", "DD 49 90 41 02 1D 52 F5 AE 47 5E D4"); // bytes_strength=2400 offset_strength=96
PATCH_LIB("libpatrons.so", "0xC412F4", "EA 04 7D C5 00 73 39 7F 84 9B 81 AB C9 B0 5C 7E"); // bytes_strength=3200 offset_strength=92
PATCH_LIB("libpatrons.so", "0x5DA79B", "6B 59 59 62 2D 4B C5 74"); // bytes_strength=1600 offset_strength=97
PATCH_LIB("libpatrons.so", "0xA6E6EF", "0C 9F E6 E6 D6 4E 05 23 AB 86"); // bytes_strength=2000 offset_strength=95
PATCH_LIB("libpatrons.so", "0x7A1E8C", "AD 70 66 3B 37 F1 0A 1D"); // bytes_strength=1600 offset_strength=95
PATCH_LIB("libpatrons.so", "0xE97911", "48 24 C8 AE 24 E4 51 A3 9F CE 1D 74 85 BC 3C EB"); // bytes_strength=3200 offset_strength=93
PATCH_LIB("libpatrons.so", "0xC52400", "4B 8D 28 21 35 71 E9 46"); // bytes_strength=1600 offset_strength=92
PATCH_LIB("libpatrons.so", "0xCBF1BB", "7A E5 B5 68 55 41 58 99 93 FA 4B C4"); // bytes_strength=2400 offset_strength=94
PATCH_LIB("libpatrons.so", "0xBB9020", "C0 2B 5F 97 EF 34 92 6C CB B8"); // bytes_strength=2000 offset_strength=91
PATCH_LIB("libpatrons.so", "0x3660ED", "DD E9 3B B5 49 DB 85 F8 DB 88 8C 2D"); // bytes_strength=2400 offset_strength=97
PATCH_LIB("libpatrons.so", "0xCC3F55", "3D 06 3B AA F7 A8 48 9E 89 4D 07"); // bytes_strength=2200 offset_strength=93
PATCH_LIB("libpatrons.so", "0x648396", "0E 04 39 B0 36 E5 99 D1 14 EB 50 E0 31 E2 33"); // bytes_strength=3000 offset_strength=97
PATCH_LIB("libpatrons.so", "0xA95874", "22 88 7A 00 EC 38 4E D9 D4 89 02"); // bytes_strength=2200 offset_strength=99
PATCH_LIB("libpatrons.so", "0x17F7F8", "15 CC 6C BE EB 0C 38 03 92"); // bytes_strength=1800 offset_strength=99
PATCH_LIB("libpatrons.so", "0x915CEC", "DA 92 B2 35 EE D8 57 58 FE FF 7A 33 5D 6D"); // bytes_strength=2800 offset_strength=98
PATCH_LIB("libpatrons.so", "0xA7B701", "06 28 08 20 70 DB 44 3F"); // bytes_strength=1600 offset_strength=97
PATCH_LIB("libpatrons.so", "0x73E8F7", "68 01 AA ED FF 65 F8 FE 6F 3D 37 7F 41 9A A5"); // bytes_strength=3000 offset_strength=90
PATCH_LIB("libpatrons.so", "0x9192FD", "55 08 E5 E5 B7 EE 08 8D 37 F9 1B 70 87"); // bytes_strength=2600 offset_strength=98
PATCH_LIB("libpatrons.so", "0xCB65D6", "84 1B 07 B9 E2 42 78 65 BD"); // bytes_strength=1800 offset_strength=95
PATCH_LIB("libpatrons.so", "0x5355AF", "0C 6D 93 15 A1 C3 1A 55 92 6D B7 BE DF 69 D7 04"); // bytes_strength=3200 offset_strength=97
PATCH_LIB("libpatrons.so", "0x8FFB24", "8E F1 23 58 6E 03 D3 45 A6 F4 85 7C A1 28 93 D5"); // bytes_strength=3200 offset_strength=97
PATCH_LIB("libpatrons.so", "0x28E368", "0D C3 6A C0 66 AB 7E 23 11 BC FD 33 9D"); // bytes_strength=2600 offset_strength=98
PATCH_LIB("libpatrons.so", "0x7BB1FD", "A4 5B 99 99 CE 85 A8 0B 89 63"); // bytes_strength=2000 offset_strength=97
PATCH_LIB("libpatrons.so", "0x905120", "64 BC 18 AA 18 C0 D1 5E F6 AE"); // bytes_strength=2000 offset_strength=95
PATCH_LIB("libpatrons.so", "0x68413F", "5F A7 4D 9D 1A 0E A4 12 DF 86 BA 79 C6 BA D6 A8"); // bytes_strength=3200 offset_strength=94
PATCH_LIB("libpatrons.so", "0xFEF908", "CC 95 FE 76 87 9B AA 9F"); // bytes_strength=1600 offset_strength=91
PATCH_LIB("libpatrons.so", "0x825FA4", "3D EB E3 55 13 B2 F3 14 E4 ED 71 22"); // bytes_strength=2400 offset_strength=99
PATCH_LIB("libpatrons.so", "0xABDBE4", "56 26 B1 89 5D 14 D1 63"); // bytes_strength=1600 offset_strength=97
PATCH_LIB("libpatrons.so", "0x4E156D", "02 5E 7D 26 9B 67 6C 17 39"); // bytes_strength=1800 offset_strength=90
PATCH_LIB("libpatrons.so", "0x71315D", "35 65 66 59 23 A2 ED 04 93 95 C0 6B B2"); // bytes_strength=2600 offset_strength=95
PATCH_LIB("libpatrons.so", "0xA2B398", "58 B3 64 65 65 41 62 BA 2E 8D 64 5C CD"); // bytes_strength=2600 offset_strength=98
PATCH_LIB("libpatrons.so", "0x361636", "CC C5 2D 30 6C CE 87 A4 6D 1F 0C"); // bytes_strength=2200 offset_strength=97
PATCH_LIB("libpatrons.so", "0xA1594D", "6F E2 A1 94 0F 6A A5 33 29 98 93 A4 27"); // bytes_strength=2600 offset_strength=93
PATCH_LIB("libpatrons.so", "0x965F82", "AA 3B 41 87 AA F8 B2 37 57 06 C5 D5 A9 70"); // bytes_strength=2800 offset_strength=99
PATCH_LIB("libpatrons.so", "0x91075B", "AE 1E 7E 80 FA C7 37 D3 33 A7 FB 72 51 1C E1 A6"); // bytes_strength=3200 offset_strength=97
PATCH_LIB("libpatrons.so", "0x3CA0AD", "0E 4B 46 23 58 D9 B5 1D"); // bytes_strength=1600 offset_strength=96
PATCH_LIB("libpatrons.so", "0xD1103B", "7A A5 F9 84 F0 A3 11 BA D9 AD"); // bytes_strength=2000 offset_strength=98
PATCH_LIB("libpatrons.so", "0x960B83", "ED 1C 2B 90 49 07 1A 16 08 4E 20 61 0B 43"); // bytes_strength=2800 offset_strength=92
PATCH_LIB("libpatrons.so", "0xD99B54", "19 1C 82 5D 9F CB 50 B9 B9 23 C2 95"); // bytes_strength=2400 offset_strength=91
PATCH_LIB("libpatrons.so", "0x8E97C2", "72 19 57 25 D8 A3 70 4C 5E 46 1C E1 39"); // bytes_strength=2600 offset_strength=93
PATCH_LIB("libpatrons.so", "0x72BB63", "67 67 A4 7F 7B E3 5D 62 A9 58 38 5A B4 6E C8"); // bytes_strength=3000 offset_strength=94
PATCH_LIB("libpatrons.so", "0x407C6F", "4A 75 FF 62 59 AF 0C 30 84 E0 4D"); // bytes_strength=2200 offset_strength=94
PATCH_LIB("libpatrons.so", "0x816640", "BC CE 82 83 DD BF F4 6A E9 21 E2 8F FC 87 EB E9"); // bytes_strength=3200 offset_strength=99
PATCH_LIB("libpatrons.so", "0xA12867", "EE 22 A3 15 0B 9F 4E 15 F1 B0 6E 54 C4"); // bytes_strength=2600 offset_strength=95
PATCH_LIB("libpatrons.so", "0x6E3E20", "D8 E5 A1 6F F9 F0 8F 27 2E CD"); // bytes_strength=2000 offset_strength=98
PATCH_LIB("libpatrons.so", "0xCBA7FF", "22 46 65 A8 35 A0 7B 47 16 B4 5D"); // bytes_strength=2200 offset_strength=96
PATCH_LIB("libpatrons.so", "0x7F02CF", "4D 88 DB 51 60 DB 76 24 D3 8B"); // bytes_strength=2000 offset_strength=95
PATCH_LIB("libpatrons.so", "0x5234AD", "0A 7F AA D6 37 B7 1C 60"); // bytes_strength=1600 offset_strength=97
PATCH_LIB("libpatrons.so", "0xA0ACBE", "1A 6E 03 1D 2C AC D5 91 B0 8D CE 6E"); // bytes_strength=2400 offset_strength=94
PATCH_LIB("libpatrons.so", "0xD4E5AA", "64 B1 A5 B1 4F EE 38 BE"); // bytes_strength=1600 offset_strength=95
PATCH_LIB("libpatrons.so", "0xC8D975", "39 B3 EE 52 2B 12 FB 89 AE 84 7B"); // bytes_strength=2200 offset_strength=91
PATCH_LIB("libpatrons.so", "0x8D218A", "1A F6 A2 AC 80 F7 94 B5 D4 FB F8 23 50 E6 2C"); // bytes_strength=3000 offset_strength=93
PATCH_LIB("libpatrons.so", "0xD45316", "36 2D 2A 8F B2 61 B3 4B 80 D7 DB 53 94 7B B7 B0"); // bytes_strength=3200 offset_strength=95
PATCH_LIB("libpatrons.so", "0xF37FF9", "D1 A2 01 95 5A B8 62 D1 B1 D7 92"); // bytes_strength=2200 offset_strength=97
PATCH_LIB("libpatrons.so", "0x6B5739", "8D 4B 9E 70 25 2C 0E 47 7E D4 72 A3 EC B9 03 7D"); // bytes_strength=3200 offset_strength=98
PATCH_LIB("libpatrons.so", "0x9C1BB2", "1F 4B AB 7F 11 7B 5C 1C 4E"); // bytes_strength=1800 offset_strength=95
PATCH_LIB("libpatrons.so", "0x338CB1", "01 4A 1C F0 AD 98 23 B4 48 4C 61 EF F3 32 CF"); // bytes_strength=3000 offset_strength=93
PATCH_LIB("libpatrons.so", "0xF57EB0", "49 CF 4C 30 9B 5D 59 51 4F 60 8B 1F AF"); 

PATCH_LIB("libDataMaster.so", "0xE30EFB", "FC 2C 5E E2 03 DC 4C 6C 92 E4 B8 A1 4E E3"); // bytes_strength=2800 offset_strength=93
PATCH_LIB("libDataMaster.so", "0x387782", "57 F3 40 EE 03 75 E7 43 38 EB AD 47 D4"); // bytes_strength=2600 offset_strength=99
PATCH_LIB("libDataMaster.so", "0xDD459A", "DF 00 A7 0F 2D 3C B0 FB 8E A5 B8 9A"); // bytes_strength=2400 offset_strength=92
PATCH_LIB("libDataMaster.so", "0xCDBD85", "2E D8 25 7D 08 83 06 7C"); // bytes_strength=1600 offset_strength=98
PATCH_LIB("libDataMaster.so", "0x6E135C", "53 B7 DA 52 7C C1 C1 E8 1D A7"); // bytes_strength=2000 offset_strength=95
PATCH_LIB("libDataMaster.so", "0xEBF68F", "B6 E2 E2 F9 9E 4E 0A 44 CD F3 80 64 4A 13 62 2A"); // bytes_strength=3200 offset_strength=92
PATCH_LIB("libDataMaster.so", "0x3C8611", "AE A4 69 94 57 F8 08 AD 56 72 9D"); // bytes_strength=2200 offset_strength=95
PATCH_LIB("libDataMaster.so", "0x2DBCCC", "09 AD CA B3 B5 2D E2 80 23 5D 20 D8"); // bytes_strength=2400 offset_strength=95
PATCH_LIB("libDataMaster.so", "0x5FFA53", "05 9B F7 4D D3 DC 07 38 6E 94 50 8B 40 0A 01"); // bytes_strength=3000 offset_strength=94
PATCH_LIB("libDataMaster.so", "0xE692EB", "79 6C EA 3A 45 CA 39 D3 2D 3D 79 84 3A 41 E3 CE"); // bytes_strength=3200 offset_strength=100
PATCH_LIB("libDataMaster.so", "0xB963A2", "DA 03 6A 3A 3F 45 11 FF"); // bytes_strength=1600 offset_strength=93
PATCH_LIB("libDataMaster.so", "0xB86774", "BC 86 3F 3C EE 49 B9 EF FE 99 79 93 D0 E5"); // bytes_strength=2800 offset_strength=96
PATCH_LIB("libDataMaster.so", "0xF00996", "C7 93 59 67 BF C3 5A 63 49 A4 09 77 15"); // bytes_strength=2600 offset_strength=100
PATCH_LIB("libDataMaster.so", "0xC1D369", "C8 36 5D 23 4E 31 87 2D 48 1E"); // bytes_strength=2000 offset_strength=93
PATCH_LIB("libDataMaster.so", "0xBF3E25", "7F DE CA 64 E0 BA 8C 87 E2 88 FC 8B C7 10 52 8F"); // bytes_strength=3200 offset_strength=100
PATCH_LIB("libDataMaster.so", "0x328CD7", "7E 59 35 22 BB 76 31 E7"); // bytes_strength=1600 offset_strength=100
PATCH_LIB("libDataMaster.so", "0x73B7C7", "F4 61 AD 2F 2A 9A B1 4D 3E"); // bytes_strength=1800 offset_strength=99
PATCH_LIB("libDataMaster.so", "0x476008", "8A 6A AC F0 74 CE 2E CD"); // bytes_strength=1600 offset_strength=97
PATCH_LIB("libDataMaster.so", "0xCF4589", "7E AB 65 6A 7D 3C 4B 71 52"); // bytes_strength=1800 offset_strength=97
PATCH_LIB("libDataMaster.so", "0x2EA11A", "4D 29 CE 08 0E 27 55 54 2B 46 67 70 60 B7"); // bytes_strength=2800 offset_strength=96
PATCH_LIB("libDataMaster.so", "0x5A4346", "8F 7E C8 A4 39 32 19 35 7D 86 1B D4"); // bytes_strength=2400 offset_strength=99
PATCH_LIB("libDataMaster.so", "0xE56542", "F6 E3 CE 04 68 15 B7 76 45"); // bytes_strength=1800 offset_strength=90
PATCH_LIB("libDataMaster.so", "0xD40EB9", "4C B3 8F 71 4F 9E D9 7D E1 90 2D 3B 81"); // bytes_strength=2600 offset_strength=94
PATCH_LIB("libDataMaster.so", "0x28DD93", "E7 8B 1B 35 5A B8 CA F9 FC 8B 0E 50 A1 62 28 82"); // bytes_strength=3200 offset_strength=95
PATCH_LIB("libDataMaster.so", "0x51E4FA", "CC 2E 87 34 59 AE 1C C5 C5 AC D8 B0 34 36 CF"); // bytes_strength=3000 offset_strength=91
PATCH_LIB("libDataMaster.so", "0xF1E960", "6D D4 E5 C7 84 54 2E 1A A8 0E"); // bytes_strength=2000 offset_strength=92
PATCH_LIB("libDataMaster.so", "0xD6D183", "0E B0 92 40 AA 01 38 F1 93 1C 13 54 82 5A 5D 6B"); // bytes_strength=3200 offset_strength=90
PATCH_LIB("libDataMaster.so", "0x8EF0FF", "5D D6 64 6D A9 09 E7 E0 AA 7D"); // bytes_strength=2000 offset_strength=94
PATCH_LIB("libDataMaster.so", "0x5FB3D1", "27 60 0B 44 D8 32 67 78 08 0F EC 44 1D 50 2E"); // bytes_strength=3000 offset_strength=96
PATCH_LIB("libDataMaster.so", "0x8721A9", "50 DA 9A AA 37 F8 D9 70 CB"); // bytes_strength=1800 offset_strength=100
PATCH_LIB("libDataMaster.so", "0x234A26", "15 0D 3E B2 41 4F 56 2D 35 6F 54 87 16"); // bytes_strength=2600 offset_strength=99
PATCH_LIB("libDataMaster.so", "0x67A987", "FB BB 70 93 D2 0F 71 50 A5 F1 4B 99 F2 4B 5D"); // bytes_strength=3000 offset_strength=96
PATCH_LIB("libDataMaster.so", "0x6CF2E2", "55 66 2D 09 76 46 33 BA 7F 91 C4 EA"); // bytes_strength=2400 offset_strength=91
PATCH_LIB("libDataMaster.so", "0x71CD6B", "CA 74 A0 A3 5E E7 FF 2B C9 41 18 12 33"); // bytes_strength=2600 offset_strength=90
PATCH_LIB("libDataMaster.so", "0x564FFB", "7C 72 38 A1 9B C8 5B 48 DC 81 68"); // bytes_strength=2200 offset_strength=91
PATCH_LIB("libDataMaster.so", "0xA2582A", "5E CD CE AA 13 ED 85 1B 4D C1 62 F8 4B"); // bytes_strength=2600 offset_strength=100
PATCH_LIB("libDataMaster.so", "0xD55944", "8C 37 3D 1A 93 2F 14 18 73 F1 F8 00 B8"); // bytes_strength=2600 offset_strength=99
PATCH_LIB("libDataMaster.so", "0x59B8FB", "B9 62 DC 1E A3 FE 29 64 87 E2 D5 FF 84"); // bytes_strength=2600 offset_strength=96
PATCH_LIB("libDataMaster.so", "0x44E0EE", "F7 5E 05 10 F1 18 AE E3 D2 D0 EC 10 90 36 86 5F"); // bytes_strength=3200 offset_strength=99
PATCH_LIB("libDataMaster.so", "0x11DF21", "8B 68 F7 C2 A0 3C C3 EB 83 14 8F 3B"); // bytes_strength=2400 offset_strength=100
PATCH_LIB("libDataMaster.so", "0x5BF3DA", "F0 8F 65 C9 14 F8 9F 70 6E"); // bytes_strength=1800 offset_strength=96
PATCH_LIB("libDataMaster.so", "0x3F9EBF", "38 71 17 97 E7 87 95 3B 05 87 2A ED 1D FB"); // bytes_strength=2800 offset_strength=93
PATCH_LIB("libDataMaster.so", "0x1483A2", "AA 8F AF 0F 41 12 71 29 CA 81 3A 04 06 37"); // bytes_strength=2800 offset_strength=90
PATCH_LIB("libDataMaster.so", "0x185C5E", "D3 22 90 38 21 D4 35 5A 19 09 9D 0D FC C8 7A 55"); // bytes_strength=3200 offset_strength=92
PATCH_LIB("libDataMaster.so", "0xED6952", "41 37 59 29 36 83 56 F0 AC 99 EA AF 7C 99 83"); // bytes_strength=3000 offset_strength=99
PATCH_LIB("libDataMaster.so", "0xCB6BD1", "98 E2 35 1B 5C B7 AA 5B 35 CC FC D0"); // bytes_strength=2400 offset_strength=100
PATCH_LIB("libDataMaster.so", "0x64A57B", "76 1B 03 CC 36 86 84 08 AE"); // bytes_strength=1800 offset_strength=96
PATCH_LIB("libDataMaster.so", "0x976B37", "44 C9 1D D9 E6 24 62 59 65 3F FC F3"); // bytes_strength=2400 offset_strength=97
PATCH_LIB("libDataMaster.so", "0x82C18E", "34 E2 F7 5B 3C 6D 27 AD 83 95 D9 98"); // bytes_strength=2400 offset_strength=100
PATCH_LIB("libDataMaster.so", "0xC0F555", "1C 37 DE 16 F2 D3 6A B0 29 31 BC 4E AE 03 25"); // bytes_strength=3000 offset_strength=94
PATCH_LIB("libDataMaster.so", "0x32E4D4", "E9 9F 20 85 2C 1C 86 9C 0F D4 3C"); // bytes_strength=2200 offset_strength=94
PATCH_LIB("libDataMaster.so", "0xBE744F", "DC D9 94 2B 7C F2 BC 41"); // bytes_strength=1600 offset_strength=93
PATCH_LIB("libDataMaster.so", "0x8CF3A5", "6B CC D4 83 EF AF D6 1F E7 11 DF AC"); // bytes_strength=2400 offset_strength=92
PATCH_LIB("libDataMaster.so", "0x578DF9", "B2 E0 AD 79 BE 1B 49 67 E7 4A C8 6A"); // bytes_strength=2400 offset_strength=94
PATCH_LIB("libDataMaster.so", "0xA637C3", "F8 DC 79 B6 82 19 60 50 7A 73 89 5A"); // bytes_strength=2400 offset_strength=90
PATCH_LIB("libDataMaster.so", "0x34D192", "C7 74 8D 92 E7 33 42 48 75 4C 5B 72 43 2C 0C 91"); // bytes_strength=3200 offset_strength=96
PATCH_LIB("libDataMaster.so", "0xE8B0DC", "59 71 6A B7 89 D4 56 16 D8 F2"); // bytes_strength=2000 offset_strength=98
PATCH_LIB("libDataMaster.so", "0xB823E6", "38 E6 0B 8A A8 16 26 8E E9 30"); // bytes_strength=2000 offset_strength=93
PATCH_LIB("libDataMaster.so", "0xF5D61A", "2B 29 7C 78 8D 07 CD E5"); // bytes_strength=1600 offset_strength=98
PATCH_LIB("libDataMaster.so", "0x79E11E", "22 37 02 54 9C D4 68 E1 09 E4 90"); // bytes_strength=2200 offset_strength=98
PATCH_LIB("libDataMaster.so", "0x191951", "94 5D A6 2E 9E DF FD 45 E7 39 E1 DE B2"); // bytes_strength=2600 offset_strength=92
PATCH_LIB("libDataMaster.so", "0xC75F99", "88 90 DB 1D 4B F0 41 FD C1 E8 37 0B 25"); // bytes_strength=2600 offset_strength=93
PATCH_LIB("libDataMaster.so", "0x8C7DA6", "9F 04 72 D9 06 05 42 99 5B 77 83 BF AB CB"); // bytes_strength=2800 offset_strength=93
PATCH_LIB("libDataMaster.so", "0x168DD0", "32 FF DA 76 82 28 89 59"); // bytes_strength=1600 offset_strength=95
PATCH_LIB("libDataMaster.so", "0xBCECC9", "1C FC B4 F7 08 FA DC 21 53 26 58 3F B4 1E AE"); // bytes_strength=3000 offset_strength=92
PATCH_LIB("libDataMaster.so", "0x33B7A5", "20 F7 4B 3A 53 04 99 D0 FA"); // bytes_strength=1800 offset_strength=97
PATCH_LIB("libDataMaster.so", "0xB59638", "A8 40 0A D1 C5 E5 F0 2D 53 36 7B"); // bytes_strength=2200 offset_strength=95
PATCH_LIB("libDataMaster.so", "0x65B387", "6C 1F 2E 58 37 AF C0 0D 76 07 E7 4C E1 F1 77"); // bytes_strength=3000 offset_strength=91
PATCH_LIB("libDataMaster.so", "0x3244F6", "79 7F 78 1B 23 44 0A 76"); // bytes_strength=1600 offset_strength=95
PATCH_LIB("libDataMaster.so", "0x742DC2", "A4 BB 48 1C 94 A3 C6 5F 8F 66"); // bytes_strength=2000 offset_strength=100
PATCH_LIB("libDataMaster.so", "0x40C293", "13 FD 82 24 97 5C CE 87 BC 93 C5 93 1D"); // bytes_strength=2600 offset_strength=93
PATCH_LIB("libDataMaster.so", "0x471020", "4B EC 0A 53 FA DA 8D 35 41 9F"); // bytes_strength=2000 offset_strength=94
PATCH_LIB("libDataMaster.so", "0x813AA8", "A3 63 B4 01 F9 70 DD 67 3E DB F6 A2 F2"); // bytes_strength=2600 offset_strength=98
PATCH_LIB("libDataMaster.so", "0x433A20", "0B 31 A8 4B CD B5 C6 B1 5B 92 2B 91 28 83 F0"); // bytes_strength=3000 offset_strength=100
PATCH_LIB("libDataMaster.so", "0x719B99", "EF 62 34 41 52 6D C5 46 46"); // bytes_strength=1800 offset_strength=99
PATCH_LIB("libDataMaster.so", "0xB363A2", "4B A4 A0 F9 66 7C 7B A5 5E"); // bytes_strength=1800 offset_strength=100
PATCH_LIB("libDataMaster.so", "0x2C6CE1", "86 61 55 44 2E A2 B1 BF FE A2 83 41 35"); // bytes_strength=2600 offset_strength=99
PATCH_LIB("libDataMaster.so", "0xB6EC52", "B1 57 16 A1 C4 DE 8B A2 60 18 89"); // bytes_strength=2200 offset_strength=98
PATCH_LIB("libDataMaster.so", "0x3A676A", "05 58 A0 DE 53 83 AA D9 DA 38 C7 CE 5C"); // bytes_strength=2600 offset_strength=92
PATCH_LIB("libDataMaster.so", "0x483A47", "A2 AC B8 BB CC 05 33 37"); // bytes_strength=1600 offset_strength=99
PATCH_LIB("libDataMaster.so", "0xAAF81F", "A1 0D E3 7C 60 3E 7E 30 46 69 E3"); // bytes_strength=2200 offset_strength=91
PATCH_LIB("libDataMaster.so", "0xBAC1A3", "D5 D1 6D DE C0 BE 94 05 78 60 A3 FD F2 B6 1D 53"); // bytes_strength=3200 offset_strength=95
PATCH_LIB("libDataMaster.so", "0xF4C96F", "C4 FF FC C5 38 FD 2E 0B 0F 09 90 18 EA A2 7D 68"); // bytes_strength=3200 offset_strength=100
PATCH_LIB("libDataMaster.so", "0x416156", "09 5C E0 CD 9F 57 94 7E 10"); // bytes_strength=1800 offset_strength=91
PATCH_LIB("libDataMaster.so", "0xF95844", "09 C1 AA EF 9D 4A 90 50"); // bytes_strength=1600 offset_strength=94
PATCH_LIB("libDataMaster.so", "0x8E37D7", "61 F8 4C 9F 12 E7 8B BF 60 4C DD 42 C5 99 BB"); // bytes_strength=3000 offset_strength=93
PATCH_LIB("libDataMaster.so", "0x940734", "66 D0 87 20 11 DA E7 20 22 B6 A6 36 98 70"); // bytes_strength=2800 offset_strength=91
PATCH_LIB("libDataMaster.so", "0x6E61B2", "B6 94 E1 67 9A 3A 7E 12 41 CF 5A"); // bytes_strength=2200 offset_strength=98
PATCH_LIB("libDataMaster.so", "0xFC6AA6", "FB D4 05 EB AD 4C EF 6D D8"); // bytes_strength=1800 offset_strength=95
PATCH_LIB("libDataMaster.so", "0x27AB78", "B0 3F C4 44 00 B3 B9 5E 08 4C 6D"); // bytes_strength=2200 offset_strength=93
PATCH_LIB("libDataMaster.so", "0x381BCE", "FB 84 EE B7 77 89 BE 89 6A 79 AB"); // bytes_strength=2200 offset_strength=92
PATCH_LIB("libDataMaster.so", "0x5272D6", "B0 3A 67 CF C3 F5 85 58 37 08 B0 5B"); // bytes_strength=2400 offset_strength=94
PATCH_LIB("libDataMaster.so", "0x1260AE", "1E 08 93 E4 BB 4B 41 CF BE 13"); // bytes_strength=2000 offset_strength=95
PATCH_LIB("libDataMaster.so", "0xD02C71", "8E D3 77 33 82 87 9E 64 EC 87 0D 53 1D 01"); // bytes_strength=2800 offset_strength=95
PATCH_LIB("libDataMaster.so", "0xA53DBB", "97 BA 87 99 9F 50 C8 DB DF C9 A0 6D 4A"); // bytes_strength=2600 offset_strength=90
PATCH_LIB("libDataMaster.so", "0xF1B031", "DA 8E FD 3E 9F 7B 63 AF 66 04 F5"); // bytes_strength=2200 offset_strength=93
PATCH_LIB("libDataMaster.so", "0xD2267A", "BF E0 C4 94 F6 7E B5 A5"); // bytes_strength=1600 offset_strength=95
PATCH_LIB("libDataMaster.so", "0xB0CE04", "0A 07 ED 0B E8 AF 9F AE 25 1D 70 A3 27"); // bytes_strength=2600 offset_strength=93
PATCH_LIB("libDataMaster.so", "0x977327", "0D 04 2E E5 7F 57 E4 77 A1 1D 9F F0 FE"); // bytes_strength=2600 offset_strength=94
PATCH_LIB("libDataMaster.so", "0xB7A137", "F7 AB 1B 93 1E E2 EF D5 1A 7E 1A"); // bytes_strength=2200 offset_strength=96
PATCH_LIB("libDataMaster.so", "0xA73B39", "52 41 88 2E 08 80 F7 5F FD E5"); // bytes_strength=2000 offset_strength=94
PATCH_LIB("libDataMaster.so", "0x666E09", "D4 28 0D F9 15 57 6E 8E 0C 06 BF 4B DA FD BB 00"); // bytes_strength=3200 offset_strength=99
PATCH_LIB("libDataMaster.so", "0x241FD7", "04 2F BE 4F BE ED 2D FC 3A 64 49"); // bytes_strength=2200 offset_strength=97
PATCH_LIB("libDataMaster.so", "0x5650E3", "BE 6A 6C BA 2F 66 DF 6C 60 9E 97 57 C7 12 FA"); // bytes_strength=3000 offset_strength=93
PATCH_LIB("libDataMaster.so", "0x4C2181", "8D FE 20 26 B9 80 E6 5A BF 9E 01"); // bytes_strength=2200 offset_strength=99
PATCH_LIB("libDataMaster.so", "0xB3E32B", "F0 AC 66 A9 90 85 C9 74 28 25 35 B3 61"); // bytes_strength=2600 offset_strength=99
PATCH_LIB("libDataMaster.so", "0xE1326A", "46 C5 10 D0 FF 39 CA BE"); // bytes_strength=1600 offset_strength=100
PATCH_LIB("libDataMaster.so", "0xB0B01D", "F6 07 9F 50 63 38 5C 0B 56 30 66 BE E4 E2 ED"); // bytes_strength=3000 offset_strength=97
PATCH_LIB("libDataMaster.so", "0x6743CB", "90 BC F3 E6 18 D4 15 C5 C0 65"); // bytes_strength=2000 offset_strength=94
PATCH_LIB("libDataMaster.so", "0x3068F5", "C0 2A 49 10 13 C9 31 3A 8F 12 FB BF 80"); // bytes_strength=2600 offset_strength=93
PATCH_LIB("libDataMaster.so", "0x36AA4F", "13 86 BD 9A DD 1A B4 93 C0 78 D9"); // bytes_strength=2200 offset_strength=97
PATCH_LIB("libDataMaster.so", "0xD10F81", "32 40 01 C2 97 30 62 AE B4 BA"); // bytes_strength=2000 offset_strength=100
PATCH_LIB("libDataMaster.so", "0xE05A7C", "25 CD FE 78 B8 06 1A 41 76"); // bytes_strength=1800 offset_strength=99
PATCH_LIB("libDataMaster.so", "0x97FC8D", "73 6F FB 7A D7 71 F5 0E 29 99 BC"); // bytes_strength=2200 offset_strength=95
PATCH_LIB("libDataMaster.so", "0x5675FE", "DE 3F 33 81 24 F9 98 43"); // bytes_strength=1600 offset_strength=100
PATCH_LIB("libDataMaster.so", "0xF64C1C", "59 7C A0 F5 8E 4F 74 FD EE 46 DA D8"); // bytes_strength=2400 offset_strength=90
PATCH_LIB("libDataMaster.so", "0x43E853", "75 EA A9 E0 66 D0 67 25 B3 8F D8"); // bytes_strength=2200 offset_strength=96
PATCH_LIB("libDataMaster.so", "0x9AE6FE", "1D E1 A8 28 09 84 F0 CB 84 70 8E 49 11 61 45 B1"); // bytes_strength=3200 offset_strength=100
PATCH_LIB("libDataMaster.so", "0x858974", "18 6F BC 11 58 41 FF B9"); // bytes_strength=1600 offset_strength=97
PATCH_LIB("libDataMaster.so", "0x8464C4", "F4 01 E9 E9 18 E4 FB A3"); // bytes_strength=1600 offset_strength=93
PATCH_LIB("libDataMaster.so", "0x34C8A8", "4A 29 09 F8 78 B8 CC 4B C3 E6 25 9A"); // bytes_strength=2400 offset_strength=93
PATCH_LIB("libDataMaster.so", "0x9B8615", "1E A6 8C 63 2B 4C 41 A0"); // bytes_strength=1600 offset_strength=92
PATCH_LIB("libDataMaster.so", "0x553BB5", "21 AD 19 1C C5 EC FE 2F 9C 9C 44 D3 03 B1 A4 9B"); // bytes_strength=3200 offset_strength=100
PATCH_LIB("libDataMaster.so", "0xB62F7F", "FF 84 F7 90 1D 96 D9 70 8F 1C 0E"); // bytes_strength=2200 offset_strength=94
PATCH_LIB("libDataMaster.so", "0x948D97", "7E EF CF 67 5F BE 58 6F AD BB 6F A2 DE"); // bytes_strength=2600 offset_strength=93
PATCH_LIB("libDataMaster.so", "0xCC02A6", "AE 43 3A 14 53 DD 3F F8 DC 54 7F"); // bytes_strength=2200 offset_strength=94
PATCH_LIB("libDataMaster.so", "0xB2A710", "79 F4 E3 24 28 94 10 9E 17"); // bytes_strength=1800 offset_strength=98
PATCH_LIB("libDataMaster.so", "0x603158", "45 9E 72 21 A0 FE 93 16 6D AC DE"); // bytes_strength=2200 offset_strength=90
PATCH_LIB("libDataMaster.so", "0xEA0C09", "13 80 9B D7 95 74 B0 5F 61 B9 8E F2"); // bytes_strength=2400 offset_strength=95
PATCH_LIB("libDataMaster.so", "0x17B8DF", "A4 51 1D C2 4E DD C3 70 2F 6C 3C 81 A1 3A CA"); // bytes_strength=3000 offset_strength=91
PATCH_LIB("libDataMaster.so", "0x113916", "55 43 4E 21 14 14 3F BF C0 82 B4 8D 34 0D 80 4B"); // bytes_strength=3200 offset_strength=91
PATCH_LIB("libDataMaster.so", "0xD97EEE", "80 4F 2D D8 27 E6 D3 68 54 AD 7E 99 AC 72"); // bytes_strength=2800 offset_strength=92
PATCH_LIB("libDataMaster.so", "0xC227E6", "DA 21 69 72 C9 EC CA 00 60 05 25 9B"); // bytes_strength=2400 offset_strength=91
PATCH_LIB("libDataMaster.so", "0x4BCB8B", "50 94 FD DA 72 B7 F7 DF C0 16 9D FE 49"); // bytes_strength=2600 offset_strength=99
PATCH_LIB("libDataMaster.so", "0xD94A27", "FD 67 12 0E 85 A1 51 F8 C8 89"); // bytes_strength=2000 offset_strength=93
PATCH_LIB("libDataMaster.so", "0x5D9EF1", "9B 53 FE A1 05 CD D1 81 36 05 B4 4F 8B 7F"); // bytes_strength=2800 offset_strength=93
PATCH_LIB("libDataMaster.so", "0x4E73B6", "97 EB CA 27 E6 31 9A A3 16"); // bytes_strength=1800 offset_strength=97
PATCH_LIB("libDataMaster.so", "0xAFC7DE", "3D 0D 9F 00 4E 83 97 83 28 65 F9 C7 50"); // bytes_strength=2600 offset_strength=91
PATCH_LIB("libDataMaster.so", "0x71B9B1", "3E C5 99 95 6F 18 60 E0 B2 F1 78 C4 72"); // bytes_strength=2600 offset_strength=95
PATCH_LIB("libDataMaster.so", "0xD0E6DE", "6B D3 83 94 03 07 3C 71 C9 07 50 C8"); // bytes_strength=2400 offset_strength=95
PATCH_LIB("libDataMaster.so", "0x3D0F4F", "D0 7A ED 8E 91 08 D7 3A"); // bytes_strength=1600 offset_strength=94
PATCH_LIB("libDataMaster.so", "0xD30243", "FE 02 C2 5B E9 70 D4 07 BA 26 04"); // bytes_strength=2200 offset_strength=98
PATCH_LIB("libDataMaster.so", "0x2D5306", "AE 1B E1 F7 C8 46 DB D2 BD F6 16"); // bytes_strength=2200 offset_strength=97
PATCH_LIB("libDataMaster.so", "0xEB63B3", "87 39 09 45 BC 67 D6 6D 41 13"); // bytes_strength=2000 offset_strength=92
PATCH_LIB("libDataMaster.so", "0x7A8FBC", "BA A3 3C 15 4C 68 83 B6 91 B7 E4 9A 13 2D 0C 64"); // bytes_strength=3200 offset_strength=98
PATCH_LIB("libDataMaster.so", "0xE4891E", "61 AF 60 37 9F 50 13 4C 70 ED AB E2"); // bytes_strength=2400 offset_strength=95
PATCH_LIB("libDataMaster.so", "0x970E51", "E7 4F E5 71 F8 9A 8C 2D 70 1B D9 70 09"); // bytes_strength=2600 offset_strength=91
PATCH_LIB("libDataMaster.so", "0x2354DF", "C8 65 6F 7E 60 E8 41 2C 85 B5 F8 04 31 C6 9F A9"); // bytes_strength=3200 offset_strength=96
PATCH_LIB("libDataMaster.so", "0x743FD7", "D9 DB 37 68 AB 15 BD 26 54 E1 97 FB 98 68 C3"); // bytes_strength=3000 offset_strength=92
PATCH_LIB("libDataMaster.so", "0x6123C3", "63 72 67 19 09 0A F8 D1 B6 AD BE 58 CF B0"); 

PATCH_LIB("libUE4.so", "0x77BEC5", "2F AF CF 86 FF 7F 01 B5 77 9F DB"); // bytes_strength=2200 offset_strength=90
PATCH_LIB("libUE4.so", "0xB25C14", "5D 79 95 0E 1B FA FC 8A A4"); // bytes_strength=1800 offset_strength=93
PATCH_LIB("libUE4.so", "0x552C2F", "B4 59 B7 A5 CD B6 75 F1 F7 30 97 DC 44 C8"); // bytes_strength=2800 offset_strength=93
PATCH_LIB("libUE4.so", "0x9D4B71", "2C 7E F8 37 3A D5 15 50 ED 46 04 2F"); // bytes_strength=2400 offset_strength=99
PATCH_LIB("libUE4.so", "0x326D46", "71 85 23 39 C5 99 38 D5 23 1C B9 7D 1F"); // bytes_strength=2600 offset_strength=94
PATCH_LIB("libUE4.so", "0x539D64", "D0 96 D5 04 E8 C5 4F 00 6F"); // bytes_strength=1800 offset_strength=97
PATCH_LIB("libUE4.so", "0x37AC64", "49 37 ED A6 49 7C 25 6E"); // bytes_strength=1600 offset_strength=94
PATCH_LIB("libUE4.so", "0xDEFFD5", "0E 8C 6B 39 2C CC F1 BC 5A 9D 7A 66 CF"); // bytes_strength=2600 offset_strength=95
PATCH_LIB("libUE4.so", "0xC3AE52", "FC F1 67 19 B9 48 F0 FC 2C 8D 17 40 5B C5 65 4D"); // bytes_strength=3200 offset_strength=99
PATCH_LIB("libUE4.so", "0x7DD53D", "BA D0 E7 88 DF A9 58 18 2D 61 0F 8E CC C1 D0"); // bytes_strength=3000 offset_strength=93
PATCH_LIB("libUE4.so", "0x8EAA57", "C2 CA 74 9E D8 CA AD C0 20 B9"); // bytes_strength=2000 offset_strength=91
PATCH_LIB("libUE4.so", "0xB0603D", "29 83 A9 48 A0 B2 1F B3 94 43 78 0A 03 24 7E"); // bytes_strength=3000 offset_strength=93
PATCH_LIB("libUE4.so", "0xE4CA89", "4F 4C 45 86 68 28 3A A7 79 76 4D C4 06 C3 9F 0F"); // bytes_strength=3200 offset_strength=94
PATCH_LIB("libUE4.so", "0xAB6E1C", "EB 5B 8B 4E C3 CB F2 C7"); // bytes_strength=1600 offset_strength=92
PATCH_LIB("libUE4.so", "0xE5BBB9", "3E 46 D9 1D 5E DE 9A C9"); // bytes_strength=1600 offset_strength=96
PATCH_LIB("libUE4.so", "0x421B82", "3D 12 08 74 E5 22 FF 1C 36 DA E0 9D AC BB"); // bytes_strength=2800 offset_strength=95
PATCH_LIB("libUE4.so", "0x836AB3", "D2 80 84 21 41 75 76 E7 F5 61 A9 F7 EE 61 D4 94"); // bytes_strength=3200 offset_strength=98
PATCH_LIB("libUE4.so", "0x4210CF", "3E CB 89 CB 37 5C 0A 4E F2 60 88 F5 AA CF 85 28"); // bytes_strength=3200 offset_strength=96
PATCH_LIB("libUE4.so", "0xDD7321", "F7 CC 6A CB 87 49 D1 1F B4 9D 7E"); // bytes_strength=2200 offset_strength=97
PATCH_LIB("libUE4.so", "0xB675D3", "9E F6 06 59 2B 91 BD 40 7D B6"); // bytes_strength=2000 offset_strength=100
PATCH_LIB("libUE4.so", "0x91787F", "5B 3F 41 9C 60 D3 6E BC 95 0B 72 08 13"); // bytes_strength=2600 offset_strength=90
PATCH_LIB("libUE4.so", "0xA0FC96", "D0 80 77 5F EC A6 D3 40"); // bytes_strength=1600 offset_strength=100
PATCH_LIB("libUE4.so", "0x27B29D", "F5 31 73 94 B9 8D 79 EB 6A D4 F1 06"); // bytes_strength=2400 offset_strength=91
PATCH_LIB("libUE4.so", "0x4BC554", "1E 70 5D B5 2E FA 88 63 1B BD 56 1B 1A A7 43 A2"); // bytes_strength=3200 offset_strength=99
PATCH_LIB("libUE4.so", "0x9A6DAF", "60 F4 96 EB 4B 4F 83 FE 2D 59 02 E4 9D DE 24"); // bytes_strength=3000 offset_strength=98
PATCH_LIB("libUE4.so", "0xA2A5EA", "FB C0 9C 30 D7 E5 5E 8F 45 7E 3A 95 6C A3 26"); // bytes_strength=3000 offset_strength=97
PATCH_LIB("libUE4.so", "0x2678D3", "49 91 A8 30 8A 2E 82 B3 B9 CB 79"); // bytes_strength=2200 offset_strength=96
PATCH_LIB("libUE4.so", "0xEEBF32", "1B 49 DA 72 0A C1 AE FE 85 8E 58 D2 F3 0E 9D"); // bytes_strength=3000 offset_strength=93
PATCH_LIB("libUE4.so", "0x7DBA64", "4F F0 24 43 AB A6 13 7F F9 9A 11 8C 4B 57 5A"); // bytes_strength=3000 offset_strength=94
PATCH_LIB("libUE4.so", "0x7B51B6", "D0 24 76 7C 26 B0 69 F7"); // bytes_strength=1600 offset_strength=95
PATCH_LIB("libUE4.so", "0xFCFE2F", "C4 3C B7 97 5C 59 2A 73 05 1C A5"); // bytes_strength=2200 offset_strength=99
PATCH_LIB("libUE4.so", "0x68061F", "98 5F D6 03 00 46 ED B2 F6 55 F3 0F DA AF"); // bytes_strength=2800 offset_strength=99
PATCH_LIB("libUE4.so", "0xEF4F2D", "4F 79 85 82 F6 14 42 DB BB F6 16"); // bytes_strength=2200 offset_strength=98
PATCH_LIB("libUE4.so", "0x3E66B3", "52 89 07 CF 91 D7 DA B7 12 18"); // bytes_strength=2000 offset_strength=92
PATCH_LIB("libUE4.so", "0xE60771", "6D 64 97 00 03 C0 06 5B 77 D2 D3 E9"); // bytes_strength=2400 offset_strength=95
PATCH_LIB("libUE4.so", "0xF89452", "C9 34 22 C3 D1 AE CE 23"); // bytes_strength=1600 offset_strength=92
PATCH_LIB("libUE4.so", "0xDC33D9", "AD 99 4D 25 41 F9 E3 47 F7 C7 8A"); // bytes_strength=2200 offset_strength=94
PATCH_LIB("libUE4.so", "0xF2E107", "90 A9 E9 2C 63 98 22 58 91 9F"); // bytes_strength=2000 offset_strength=100
PATCH_LIB("libUE4.so", "0x3EEC3A", "EF 3D F5 09 02 32 5C E9 7D C5 CA FD 45"); // bytes_strength=2600 offset_strength=93
PATCH_LIB("libUE4.so", "0x92206D", "D2 37 A5 77 43 51 04 8E 70 BE 53 AC B4 34"); // bytes_strength=2800 offset_strength=98
PATCH_LIB("libUE4.so", "0x9E7CDB", "2B EC 79 23 25 D9 53 26 42 E8"); // bytes_strength=2000 offset_strength=99
PATCH_LIB("libUE4.so", "0xA308CA", "07 5F AE F0 2D 51 0A 1A 67"); // bytes_strength=1800 offset_strength=97
PATCH_LIB("libUE4.so", "0x6450EF", "23 68 8D 91 5F 47 03 58"); // bytes_strength=1600 offset_strength=92
PATCH_LIB("libUE4.so", "0xB3FDD3", "72 1B 8D 74 92 D8 DD F9 58 0B C8 1B 14 CF"); // bytes_strength=2800 offset_strength=91
PATCH_LIB("libUE4.so", "0x15F0C8", "A5 6F 77 1F 27 44 BD 63 68 EB 64 F2 CC"); // bytes_strength=2600 offset_strength=96
PATCH_LIB("libUE4.so", "0xB5D8E5", "3B 4D E0 FC 5B 3E 2A 06 BC 1B 58 3D E2"); // bytes_strength=2600 offset_strength=91
PATCH_LIB("libUE4.so", "0x8C7411", "C3 87 52 00 82 CD 3D 22"); // bytes_strength=1600 offset_strength=96
PATCH_LIB("libUE4.so", "0x1C76A3", "15 96 54 41 7F D0 46 93 E6 8F 43 26 27 B8 8B 0C"); // bytes_strength=3200 offset_strength=99
PATCH_LIB("libUE4.so", "0x52528A", "D9 54 6A A8 90 C9 EB B2 0E 51 83 06 E5 CE"); // bytes_strength=2800 offset_strength=97
PATCH_LIB("libUE4.so", "0x13B9B3", "0C B7 E6 2E 21 77 2E B6 E6 EC 74"); // bytes_strength=2200 offset_strength=99
PATCH_LIB("libUE4.so", "0xD5EB5E", "18 D9 4F D8 18 22 F7 EB"); // bytes_strength=1600 offset_strength=95
PATCH_LIB("libUE4.so", "0xF5B9FE", "0F 58 31 A2 EA D8 09 63 67 D0 D2 33 8A 85 88"); // bytes_strength=3000 offset_strength=98
PATCH_LIB("libUE4.so", "0x5AD222", "66 50 C2 61 79 00 92 A1"); // bytes_strength=1600 offset_strength=99
PATCH_LIB("libUE4.so", "0xD3ABB7", "18 AE 02 B2 B4 97 7C B8 65"); // bytes_strength=1800 offset_strength=93
PATCH_LIB("libUE4.so", "0x1FCCE0", "58 16 F3 A9 6C D5 5E 67 9F 7A B0 2F"); // bytes_strength=2400 offset_strength=92
PATCH_LIB("libUE4.so", "0x29CE3A", "68 73 AF 76 CC B4 64 EF"); // bytes_strength=1600 offset_strength=96
PATCH_LIB("libUE4.so", "0x3B0913", "23 1D 88 B4 38 B5 BE 81 A9"); // bytes_strength=1800 offset_strength=92
PATCH_LIB("libUE4.so", "0x81A725", "BA 30 53 CB FF 31 89 24 43 39 44 5C 84 D8 1F F2"); // bytes_strength=3200 offset_strength=94
PATCH_LIB("libUE4.so", "0xD72CFB", "2D F2 08 92 29 4C 79 46 61 44 60 F2 DB 3B DF"); // bytes_strength=3000 offset_strength=100
PATCH_LIB("libUE4.so", "0xC53C4B", "F9 25 73 24 5D 97 2E F0 F8 84 6B B0 6E"); // bytes_strength=2600 offset_strength=96
PATCH_LIB("libUE4.so", "0x7BF7DE", "C6 94 E4 6C E0 F6 7B 0F 11 7E"); // bytes_strength=2000 offset_strength=100
PATCH_LIB("libUE4.so", "0xC325EE", "0C 36 F1 25 7E 9F 14 0A 58 4B E3"); // bytes_strength=2200 offset_strength=93
PATCH_LIB("libUE4.so", "0x351C4D", "4E F8 EB BC 68 C8 DC 89 90 38 00 72 7B 1D A9 0D"); // bytes_strength=3200 offset_strength=93
PATCH_LIB("libUE4.so", "0x575BCC", "0C 2B A3 57 D7 3D C6 86 20 64 10 27 ED"); // bytes_strength=2600 offset_strength=93
PATCH_LIB("libUE4.so", "0x9E647C", "5D 23 AC A8 A4 A9 EF E9 51 82 F3 4A 2C F5 58 AA"); // bytes_strength=3200 offset_strength=100
PATCH_LIB("libUE4.so", "0x414909", "D3 CA 4C 3A AF 26 C9 9C E6 75 77 0D 01 90 EC 9B"); // bytes_strength=3200 offset_strength=95
PATCH_LIB("libUE4.so", "0x36AC65", "22 A5 15 F4 07 23 2C A1 79 6E"); // bytes_strength=2000 offset_strength=90
PATCH_LIB("libUE4.so", "0x5439FF", "AE B4 AE D1 A2 1E D4 2E DD 2A 8E D9 41 DE 01"); // bytes_strength=3000 offset_strength=90
PATCH_LIB("libUE4.so", "0x39EE2D", "D0 EC A5 4C 05 1A DA D7 DB E4 04"); // bytes_strength=2200 offset_strength=90
PATCH_LIB("libUE4.so", "0xF15C28", "E3 AA 70 E2 C5 09 44 07 92 84 45 DC CD"); // bytes_strength=2600 offset_strength=93
PATCH_LIB("libUE4.so", "0x539CA9", "00 24 43 EB E5 71 2A AF 7F 49 F8 48"); // bytes_strength=2400 offset_strength=93
PATCH_LIB("libUE4.so", "0xFE3F31", "DA 9A 67 1E 35 BB B4 ED 99 90 90 EE F1 02 76 2B"); // bytes_strength=3200 offset_strength=91
PATCH_LIB("libUE4.so", "0xF8276F", "6F 2F 6C 92 64 6E 5E B7"); // bytes_strength=1600 offset_strength=100
PATCH_LIB("libUE4.so", "0xB2CDCD", "60 E4 8A 3A 5C 48 70 A5"); // bytes_strength=1600 offset_strength=91
PATCH_LIB("libUE4.so", "0x5DAE4B", "D4 A1 43 D3 DA DD CB BE 14 49"); // bytes_strength=2000 offset_strength=94
PATCH_LIB("libUE4.so", "0x12954A", "0C 2B 27 EC 88 23 B4 97 FD E3 9B D1 61 E5 BF 45"); // bytes_strength=3200 offset_strength=97
PATCH_LIB("libUE4.so", "0x4F85A5", "CB 92 E1 72 60 15 62 E8 73 19 B9 60"); // bytes_strength=2400 offset_strength=93
PATCH_LIB("libUE4.so", "0x60CFFD", "E3 F1 B5 40 5B AC B9 68 71 D4 0E 6E 78"); // bytes_strength=2600 offset_strength=97
PATCH_LIB("libUE4.so", "0x3F7B93", "10 56 9C 82 5D 8F C5 D9 21 27 2C 56 B4 52"); // bytes_strength=2800 offset_strength=94
PATCH_LIB("libUE4.so", "0x1FF98F", "05 13 B5 B9 4E 05 D8 BD 59 AE FC"); // bytes_strength=2200 offset_strength=94
PATCH_LIB("libUE4.so", "0xC3EF80", "E1 31 EA FA 42 7E C3 71 98 15 54 D6 39 D5 2D"); // bytes_strength=3000 offset_strength=98
PATCH_LIB("libUE4.so", "0xB0199E", "A0 C3 1B 52 81 9D 07 C9 01"); // bytes_strength=1800 offset_strength=98
PATCH_LIB("libUE4.so", "0x707698", "68 8D E7 64 17 A3 6A BE 01 7B 15 A9 04 DA"); // bytes_strength=2800 offset_strength=99
PATCH_LIB("libUE4.so", "0xB578CD", "05 29 B6 D1 82 75 77 BF 4C E8 17"); // bytes_strength=2200 offset_strength=90
PATCH_LIB("libUE4.so", "0x41F265", "33 B8 C0 EE 04 48 69 CE B4 34 F5 FB 19 43 9D 3A"); // bytes_strength=3200 offset_strength=96
PATCH_LIB("libUE4.so", "0xD7A2B7", "0F 3C 8F 40 A4 74 F7 C6 02 33"); // bytes_strength=2000 offset_strength=91
PATCH_LIB("libUE4.so", "0x80A16D", "8D 03 57 14 35 97 1A 70"); // bytes_strength=1600 offset_strength=98
PATCH_LIB("libUE4.so", "0x539824", "EE 4A 68 E6 74 7A 27 79 67 23 06 98 D6 AF CA 1D"); // bytes_strength=3200 offset_strength=96
PATCH_LIB("libUE4.so", "0xD279A7", "E3 7E 2C 31 B3 98 A3 1B DA AB 8B D8 EE A8 94 19"); // bytes_strength=3200 offset_strength=94
PATCH_LIB("libUE4.so", "0xECB33E", "23 81 2B AD 7B 23 6B 6E 06 59 B3 B5 85 7E B1 76"); // bytes_strength=3200 offset_strength=91
PATCH_LIB("libUE4.so", "0x9B3305", "98 3C E2 F7 46 B2 B2 70 DF 41 E0 7A 75 96 E1 17"); // bytes_strength=3200 offset_strength=96
PATCH_LIB("libUE4.so", "0x9C4F73", "63 78 DE 4C 49 94 23 EE DE 0F F1 E4 61 8F"); // bytes_strength=2800 offset_strength=100
PATCH_LIB("libUE4.so", "0x5D14F6", "CF BD 6A 0A 22 E6 68 1F B3 2F 62 39 A7 E0"); // bytes_strength=2800 offset_strength=92
PATCH_LIB("libUE4.so", "0xCF26C6", "CE 50 90 8A 9D 49 63 74"); // bytes_strength=1600 offset_strength=94
PATCH_LIB("libUE4.so", "0xD51CEF", "C8 F2 DF 8D 28 BA CE C6 00 59 FE D9 5E"); // bytes_strength=2600 offset_strength=94
PATCH_LIB("libUE4.so", "0x98B56F", "D7 F5 C0 FE 0A 00 DB 19 F4 84 8D 6C 3C"); // bytes_strength=2600 offset_strength=98
PATCH_LIB("libUE4.so", "0x217991", "16 64 08 CA EE 97 F4 36 09 65 54 56 38 48 5B"); // bytes_strength=3000 offset_strength=95
PATCH_LIB("libUE4.so", "0xAC8EB5", "8D A5 85 13 7A AE 2D 2A D5 1E 6A 76 15 23 1A 23"); // bytes_strength=3200 offset_strength=95
PATCH_LIB("libUE4.so", "0x757352", "D7 D8 96 59 B1 CD AF 53 1D"); // bytes_strength=1800 offset_strength=94
PATCH_LIB("libUE4.so", "0xE77EAA", "C4 11 C1 AA 94 59 BE 4D EE 70 EE"); // bytes_strength=2200 offset_strength=95
PATCH_LIB("libUE4.so", "0x63C1C3", "DB 2B 52 DE 06 30 D7 09 7F BB A1 BE 47 4F FB"); // bytes_strength=3000 offset_strength=97
PATCH_LIB("libUE4.so", "0x1C7665", "69 25 4E 72 34 A8 8C C8 E4"); // bytes_strength=1800 offset_strength=90
PATCH_LIB("libUE4.so", "0x3DF648", "44 3F A1 7F 6F 03 77 C4 D3 34 CF 6F"); // bytes_strength=2400 offset_strength=91
PATCH_LIB("libUE4.so", "0xDFA75A", "28 78 5A 86 40 F0 DE AA BE BE 52 5B D2 9F 80"); // bytes_strength=3000 offset_strength=93
PATCH_LIB("libUE4.so", "0xB61974", "A5 26 94 44 5A B0 8F BF 3A DA 41 C0 B9 5D"); // bytes_strength=2800 offset_strength=92
PATCH_LIB("libUE4.so", "0x8069D0", "4D 9D 99 BC D5 74 A4 A0 D6 69 11 99 F4"); // bytes_strength=2600 offset_strength=91
PATCH_LIB("libUE4.so", "0x9256BF", "4B E0 7D C2 C0 1B 4E 69 B4"); // bytes_strength=1800 offset_strength=94
PATCH_LIB("libUE4.so", "0xD416A0", "C7 B8 12 CE F2 87 85 0B 35 24"); // bytes_strength=2000 offset_strength=91
PATCH_LIB("libUE4.so", "0x52BE93", "3D 87 62 CB BE EA 0C 65 E6 A7"); // bytes_strength=2000 offset_strength=95
PATCH_LIB("libUE4.so", "0x5ED536", "2B AE B9 C2 C2 05 35 AF 42 89 A7 F0 0A 4D"); // bytes_strength=2800 offset_strength=91
PATCH_LIB("libUE4.so", "0x29031B", "D5 F3 55 CC 93 0B 2F 72 07"); // bytes_strength=1800 offset_strength=91
PATCH_LIB("libUE4.so", "0x996703", "22 37 4A F6 3E 9E CB B8 A7 93 C1 09"); // bytes_strength=2400 offset_strength=100
PATCH_LIB("libUE4.so", "0xA2FCC6", "28 92 D2 6B 2F 1C 9D AD DC D7 5A F1 41 56 19 B6"); // bytes_strength=3200 offset_strength=95
PATCH_LIB("libUE4.so", "0xAECB83", "5A 65 57 A0 D2 FA DF A7 B7 E4 1B 97 70 C6 E6"); // bytes_strength=3000 offset_strength=94
PATCH_LIB("libUE4.so", "0xAD0878", "0A B0 E5 32 80 94 B0 56 90 29 8F 44 10 5C 9E"); // bytes_strength=3000 offset_strength=97
PATCH_LIB("libUE4.so", "0xF30C46", "78 59 31 6B F3 E2 9B 29 66 E5 46 54 77 75 DA"); // bytes_strength=3000 offset_strength=96
PATCH_LIB("libUE4.so", "0xDEDAFE", "22 54 3A C7 CF AF 50 53 F9"); // bytes_strength=1800 offset_strength=97
PATCH_LIB("libUE4.so", "0x20003B", "5C B9 25 F3 43 72 2E 0A F8 96 34 51"); // bytes_strength=2400 offset_strength=90
PATCH_LIB("libUE4.so", "0xA8C3F6", "BF D6 B7 3B 0B 6B 0D CA 3F"); // bytes_strength=1800 offset_strength=100
PATCH_LIB("libUE4.so", "0xAEE110", "EC C6 A3 1A EB 79 A9 34 45 D8 35"); // bytes_strength=2200 offset_strength=100
PATCH_LIB("libUE4.so", "0x38F4B2", "6B 1B B5 D5 62 6B 2A 14 DE 4C 3E"); // bytes_strength=2200 offset_strength=96
PATCH_LIB("libUE4.so", "0x60209D", "94 16 B7 EA 55 57 AA 18 69 14 3E 7C FE"); // bytes_strength=2600 offset_strength=90
PATCH_LIB("libUE4.so", "0x584AEF", "D2 BF 40 BD 2A D4 6D A9 0F F5 A2 76 C5 03 3B 50"); // bytes_strength=3200 offset_strength=93
PATCH_LIB("libUE4.so", "0xCC347A", "98 0D A0 B3 9B 7C 2E 9C 4B"); // bytes_strength=1800 offset_strength=90
PATCH_LIB("libUE4.so", "0x9054A2", "9A 7E 6F 52 3C AD 19 FA D8 EC DA 92 01 09"); // bytes_strength=2800 offset_strength=99
PATCH_LIB("libUE4.so", "0x798537", "83 D1 96 FE 86 BE 0E 6B"); // bytes_strength=1600 offset_strength=100
PATCH_LIB("libUE4.so", "0x2DF69C", "0B C8 FC 8E F7 7E 87 7D CC 12 4C 2B 01 4E A7 F7"); // bytes_strength=3200 offset_strength=92
PATCH_LIB("libUE4.so", "0x76452F", "A3 D5 AC 4B 6A 61 48 9F EA 92 5F 85 B3 C1 C3"); // bytes_strength=3000 offset_strength=100
PATCH_LIB("libUE4.so", "0xCA362B", "12 FF 83 01 E7 11 0F 59 8C 14"); // bytes_strength=2000 offset_strength=97
PATCH_LIB("libUE4.so", "0xBECC5D", "06 B9 E9 D6 79 E8 58 79 0D 29 5F"); // bytes_strength=2200 offset_strength=95
PATCH_LIB("libUE4.so", "0x4E4182", "A2 E6 46 D4 01 93 0F 94 2A C4"); // bytes_strength=2000 offset_strength=93
PATCH_LIB("libUE4.so", "0x21AFC8", "96 24 EB 58 55 39 A3 D0 47 54 6B 3D"); // bytes_strength=2400 offset_strength=94
PATCH_LIB("libUE4.so", "0xBC3FF7", "D2 7B 2A D5 D4 C3 35 01 D1 A5 D4 DA CC 77 6E 1E"); // bytes_strength=3200 offset_strength=95
PATCH_LIB("libUE4.so", "0x18A535", "EC 30 BE E8 A2 C2 D4 26 A0 21 20 6F DD"); // bytes_strength=2600 offset_strength=96
PATCH_LIB("libUE4.so", "0x63FA1F", "E1 06 76 F5 22 52 51 FB 71 B7 DA F3 F0 92"); // bytes_strength=2800 offset_strength=96
PATCH_LIB("libUE4.so", "0x436425", "15 65 E3 2A 97 9F 96 13 AB 4B"); // bytes_strength=2000 offset_strength=100
PATCH_LIB("libUE4.so", "0x7E2F50", "49 7C 85 E4 3A D2 26 FF 4B 1C 75 57 C4 27 F3 DF"); // bytes_strength=3200 offset_strength=90
PATCH_LIB("libUE4.so", "0x985D6C", "D0 11 50 F3 8A C5 8C FB"); // bytes_strength=1600 offset_strength=95
PATCH_LIB("libUE4.so", "0xE8BD22", "E6 BE 22 8F 54 24 44 AC B8 81 36 70"); // bytes_strength=2400 offset_strength=93
PATCH_LIB("libUE4.so", "0xA8B180", "0E E5 31 A9 9F 8B E9 FF F7 4E"); // bytes_strength=2000 offset_strength=94
PATCH_LIB("libUE4.so", "0x387B76", "29 83 C0 1D A3 A0 C6 89"); // bytes_strength=1600 offset_strength=91
PATCH_LIB("libUE4.so", "0x65B161", "83 97 91 1D 2F FD 4C 46 27 F7 A3"); // bytes_strength=2200 offset_strength=97
PATCH_LIB("libUE4.so", "0x8314D5", "E9 31 88 11 3F 52 25 7C E7 E7 4E 03 21 1B 80 96"); // bytes_strength=3200 offset_strength=90
PATCH_LIB("libUE4.so", "0x2BF15B", "E9 93 B0 C4 53 F3 90 97 D8 69 12"); // bytes_strength=2200 offset_strength=91
PATCH_LIB("libUE4.so", "0xE85FF0", "FA 1D 25 F8 6C 34 44 8B 51 E5 4D 3E 53 60"); // bytes_strength=2800 offset_strength=93
PATCH_LIB("libUE4.so", "0xC4E765", "80 80 6D 98 CC 91 53 F7"); // bytes_strength=1600 offset_strength=95
PATCH_LIB("libUE4.so", "0x8C8045", "59 5D 87 C3 17 47 4B E3"); // bytes_strength=1600 offset_strength=90
PATCH_LIB("libUE4.so", "0xB6FD12", "C2 6D 84 34 9D 09 DF EC 1B A7 DE E3"); // bytes_strength=2400 offset_strength=100
PATCH_LIB("libUE4.so", "0x5A2106", "5D 61 C5 7F EF BB FE E3 7D A5 7F 6F"); // bytes_strength=2400 offset_strength=94
PATCH_LIB("libUE4.so", "0xE0B33A", "4B 05 74 C7 AF B7 93 BB 32 9F 84 74 01 FF");

PATCH_LIB("libGCloud.so", "0xC3E8FA", "FA C0 9F 14 6A 2D 77 33"); // bytes_strength=1600 offset_strength=99
PATCH_LIB("libGCloud.so", "0xA977BA", "BB 37 7F D4 03 72 E7 77 64"); // bytes_strength=1800 offset_strength=94
PATCH_LIB("libGCloud.so", "0x6C410B", "A7 4A 78 31 2C 2D DF AA 26 8B 96 39 70 38 39"); // bytes_strength=3000 offset_strength=95
PATCH_LIB("libGCloud.so", "0xDFF5A8", "C2 E2 AB E4 C3 AC BE AE E9 E3 96 D0 68 13 96"); // bytes_strength=3000 offset_strength=90
PATCH_LIB("libGCloud.so", "0x4B2846", "F9 21 BA 76 C5 9B DD 44 72 27 14 19"); // bytes_strength=2400 offset_strength=92
PATCH_LIB("libGCloud.so", "0x2D6FA7", "42 11 64 E0 CC 65 4A 94 F6 8F BC"); // bytes_strength=2200 offset_strength=99
PATCH_LIB("libGCloud.so", "0x10EB02", "5A 00 C1 A2 00 AF 83 CC 62"); // bytes_strength=1800 offset_strength=98
PATCH_LIB("libGCloud.so", "0xAC4C81", "01 66 0E 2C 36 2B F6 51 6C CC"); // bytes_strength=2000 offset_strength=96
PATCH_LIB("libGCloud.so", "0x4E8BD6", "E2 E1 B8 F1 B5 C6 2A 93 CB 7D D2 23 0E 5B BD"); // bytes_strength=3000 offset_strength=97
PATCH_LIB("libGCloud.so", "0x51E922", "92 2E 85 8F 91 AD 18 9F E1 76 19 DA 08 D9 DB"); // bytes_strength=3000 offset_strength=92
PATCH_LIB("libGCloud.so", "0x79A3C5", "36 7F 56 C4 7D 57 03 F2 B8 B8 FF FB 02"); // bytes_strength=2600 offset_strength=92
PATCH_LIB("libGCloud.so", "0xF1D2C0", "36 C5 0E 96 B4 70 B6 F7 1B 39"); // bytes_strength=2000 offset_strength=97
PATCH_LIB("libGCloud.so", "0xEFB517", "5E 75 85 75 53 82 DE 3F 08 11 30 80 8E FD C2"); // bytes_strength=3000 offset_strength=93
PATCH_LIB("libGCloud.so", "0x4C8ADC", "DC AE F0 F9 81 1F 79 AF D1 ED 50"); // bytes_strength=2200 offset_strength=93
PATCH_LIB("libGCloud.so", "0x8D3FAE", "15 2E DD D1 1D C7 F6 97 0D DF 8D 5B 5D"); // bytes_strength=2600 offset_strength=95
PATCH_LIB("libGCloud.so", "0x239170", "C1 62 A6 D3 7B 3E D9 F5 80 65 EE"); // bytes_strength=2200 offset_strength=94
PATCH_LIB("libGCloud.so", "0x6C2C5B", "5F 0C 22 44 BD 90 E5 26 CA 29"); // bytes_strength=2000 offset_strength=99
PATCH_LIB("libGCloud.so", "0x4EC30F", "B5 48 22 2E 71 4D DA 24 11 A5 D1 F4 28 15 58"); // bytes_strength=3000 offset_strength=98
PATCH_LIB("libGCloud.so", "0xBDE0B7", "E4 B6 35 BD 06 3B B5 E7"); // bytes_strength=1600 offset_strength=92
PATCH_LIB("libGCloud.so", "0x849E19", "4B 65 99 7D E1 39 E8 27 A1 4A"); // bytes_strength=2000 offset_strength=92
PATCH_LIB("libGCloud.so", "0x804536", "44 DB A6 40 41 2A D9 AB 28 12 14 3E 37 4A 9C"); // bytes_strength=3000 offset_strength=98
PATCH_LIB("libGCloud.so", "0xE60A8B", "DC C9 45 F9 B2 25 AF 55 FC 65 88 93 09 90 53"); // bytes_strength=3000 offset_strength=99
PATCH_LIB("libGCloud.so", "0x981895", "00 01 A4 0D 84 9D B5 96 64 15 27 1D 02 9E"); // bytes_strength=2800 offset_strength=95
PATCH_LIB("libGCloud.so", "0xAA3643", "04 5D 4F 26 38 03 18 9D B1 FB 13 55 3A 90 5C 5F"); // bytes_strength=3200 offset_strength=91
PATCH_LIB("libGCloud.so", "0xDF5557", "AE 47 05 54 D5 A2 7A B6 8C A6 B8"); // bytes_strength=2200 offset_strength=94
PATCH_LIB("libGCloud.so", "0xFEEE51", "17 B3 02 AF ED F3 57 98 D7 2D"); // bytes_strength=2000 offset_strength=95
PATCH_LIB("libGCloud.so", "0x681ACB", "0B B6 24 BC 11 80 6F 22 8B"); // bytes_strength=1800 offset_strength=95
PATCH_LIB("libGCloud.so", "0x5FEB79", "BF DF 5B 21 26 E6 D3 02 98 29 B7 BD 70 5D 46 60"); // bytes_strength=3200 offset_strength=96
PATCH_LIB("libGCloud.so", "0x2598C0", "46 60 2F 60 9E 7A 86 71 58"); // bytes_strength=1800 offset_strength=93
PATCH_LIB("libGCloud.so", "0xFF098A", "29 6D 14 D0 58 4D 0B FA 52 2C 8B 14 63 21"); // bytes_strength=2800 offset_strength=90
PATCH_LIB("libGCloud.so", "0x815BAD", "DE 35 7D 27 F7 B8 02 7B 49 3A 99 8E A9 D1"); // bytes_strength=2800 offset_strength=96
PATCH_LIB("libGCloud.so", "0xA97088", "08 7B AB CC 96 48 EB A1 5C 54 65 6E 54"); // bytes_strength=2600 offset_strength=95
PATCH_LIB("libGCloud.so", "0x9A126E", "4D 4C 80 24 FF 2B C5 3B 4D 03 48 6B 29 AF"); // bytes_strength=2800 offset_strength=96
PATCH_LIB("libGCloud.so", "0x11198D", "F2 60 1A 30 9E 5D C2 76 99 94 A8 BD"); // bytes_strength=2400 offset_strength=96
PATCH_LIB("libGCloud.so", "0xA92AAE", "F9 61 04 C5 74 F0 87 43"); // bytes_strength=1600 offset_strength=98
PATCH_LIB("libGCloud.so", "0x52073F", "E1 1E AB B2 D4 81 AC 29 4B A8"); // bytes_strength=2000 offset_strength=92
PATCH_LIB("libGCloud.so", "0xEA3081", "1D 32 CA B1 C1 4A 82 99 94 9E 45 DB"); // bytes_strength=2400 offset_strength=98
PATCH_LIB("libGCloud.so", "0x236101", "A1 FF 9E 59 57 4F 8A 37"); // bytes_strength=1600 offset_strength=93
PATCH_LIB("libGCloud.so", "0xCD3E49", "2A 24 CD 00 D2 8F 0C 41"); // bytes_strength=1600 offset_strength=98
PATCH_LIB("libGCloud.so", "0xBB379F", "0B AB 23 A9 FB 35 EB 4D"); // bytes_strength=1600 offset_strength=94
PATCH_LIB("libGCloud.so", "0x6F7BE0", "FB 6D 04 74 8D 40 E0 96 34 35 C0 BA E1 9D 2F"); // bytes_strength=3000 offset_strength=100
PATCH_LIB("libGCloud.so", "0xE09061", "80 52 87 06 EE 20 0A 0C 02 FB AC 06 4F"); // bytes_strength=2600 offset_strength=97
PATCH_LIB("libGCloud.so", "0x31B515", "D0 54 DA 4B 06 4C CA 0C B4 A7 62 56 D0 12"); // bytes_strength=2800 offset_strength=90
PATCH_LIB("libGCloud.so", "0x897C47", "AB 2B 00 E6 BF A5 9A AB 00 00 B5 A5 08 ED B5 D4"); // bytes_strength=3200 offset_strength=98
PATCH_LIB("libGCloud.so", "0x5DE7BA", "DB 83 B3 53 1B 83 12 41 46 81 1A 20 7C 60 B8"); // bytes_strength=3000 offset_strength=93
PATCH_LIB("libGCloud.so", "0xEB3D86", "45 2C 69 DE 66 98 A2 B2 10 2F 12 DC 01 00 57 CD"); // bytes_strength=3200 offset_strength=91
PATCH_LIB("libGCloud.so", "0x287A91", "59 F1 A9 0C C4 50 24 31 8B F7 8A 7C 02"); // bytes_strength=2600 offset_strength=96
PATCH_LIB("libGCloud.so", "0x4082E9", "4C CB 91 D2 67 AD E2 12 79 0F"); // bytes_strength=2000 offset_strength=99
PATCH_LIB("libGCloud.so", "0x570BDF", "DE A8 B9 36 26 F4 72 7D ED 5D 1D 86 7C"); // bytes_strength=2600 offset_strength=95
PATCH_LIB("libGCloud.so", "0xAD8A2B", "26 09 48 F4 69 03 1A 49 AA"); // bytes_strength=1800 offset_strength=94
PATCH_LIB("libGCloud.so", "0x2A830F", "29 E0 3B A9 18 55 E3 16 63"); // bytes_strength=1800 offset_strength=97
PATCH_LIB("libGCloud.so", "0x599984", "A5 2F 6A 4C BC F9 33 3A 8D A4"); // bytes_strength=2000 offset_strength=98
PATCH_LIB("libGCloud.so", "0xEC0453", "60 16 B6 1C 1C 58 0A 8B EE 5A CD D0 99 A6"); // bytes_strength=2800 offset_strength=97
PATCH_LIB("libGCloud.so", "0xFE3FA1", "5B BD E4 E0 C5 2D 12 D0"); // bytes_strength=1600 offset_strength=98
PATCH_LIB("libGCloud.so", "0x5534AB", "CE FE C5 72 A1 B0 3B B1 93 97 A0 32"); // bytes_strength=2400 offset_strength=93
PATCH_LIB("libGCloud.so", "0xA44597", "06 78 D7 FE 88 D1 1E 32 A3 7B"); // bytes_strength=2000 offset_strength=100
PATCH_LIB("libGCloud.so", "0xC70518", "E0 40 15 64 DA 09 BF BB 64 AF 94"); // bytes_strength=2200 offset_strength=98
PATCH_LIB("libGCloud.so", "0xD5D344", "8D EB 09 7D D0 EF 7F 7E A0 26"); // bytes_strength=2000 offset_strength=99
PATCH_LIB("libGCloud.so", "0xC02F39", "55 1D 42 FE 9A 3A 72 4E 35 00 45 00 45 87 AA"); // bytes_strength=3000 offset_strength=93
PATCH_LIB("libGCloud.so", "0xA6C59A", "77 81 72 92 ED 30 A6 A8 01 49 BE 55 F2"); // bytes_strength=2600 offset_strength=100
PATCH_LIB("libGCloud.so", "0x9B5D38", "BF 06 ED B9 46 0B 3E 4C B6 E8 A9 73 0C D6 0C F9"); // bytes_strength=3200 offset_strength=97
PATCH_LIB("libGCloud.so", "0xB4E2F6", "BC A6 5D F1 14 FE 61 4F 53 ED"); // bytes_strength=2000 offset_strength=90
PATCH_LIB("libGCloud.so", "0x84121C", "8E 16 5B AF 50 9D 0C 50"); // bytes_strength=1600 offset_strength=94
PATCH_LIB("libGCloud.so", "0xB35118", "8E 9C 1F 13 35 40 27 91 3A 28"); // bytes_strength=2000 offset_strength=91
PATCH_LIB("libGCloud.so", "0x4CC782", "E6 30 E2 68 B1 1C 1F 81 7E"); // bytes_strength=1800 offset_strength=91
PATCH_LIB("libGCloud.so", "0x319DD5", "83 5C DE B8 82 71 A4 B9 9C 8E F5 01 08 CC 4C"); // bytes_strength=3000 offset_strength=92
PATCH_LIB("libGCloud.so", "0xDE2B26", "04 D7 F5 AD DB 7A 5C 24 8C 6F 35 2C 3C 45 1B 62"); // bytes_strength=3200 offset_strength=90
PATCH_LIB("libGCloud.so", "0x8E0EAD", "AC A1 CC CF 51 DE 82 7D C0 36 C5 46 BF 1F"); // bytes_strength=2800 offset_strength=98
PATCH_LIB("libGCloud.so", "0x9338F6", "24 48 F1 86 37 EF 18 5F 65"); // bytes_strength=1800 offset_strength=93
PATCH_LIB("libGCloud.so", "0x7467B3", "C8 07 E7 0D ED 7E 12 DD 1E 69 7E"); // bytes_strength=2200 offset_strength=90
PATCH_LIB("libGCloud.so", "0x8AF001", "B9 20 73 C5 8B 01 13 25 63 5A"); // bytes_strength=2000 offset_strength=94
PATCH_LIB("libGCloud.so", "0x2B60C4", "C9 EA 1F BD 15 BF 8E 37 88 1F 87 53 68 04 21"); // bytes_strength=3000 offset_strength=98
PATCH_LIB("libGCloud.so", "0xD0B738", "75 C3 A2 D1 7C F2 32 1B 64"); // bytes_strength=1800 offset_strength=97
PATCH_LIB("libGCloud.so", "0xA702E9", "D1 48 E3 A0 84 CB 72 B2"); // bytes_strength=1600 offset_strength=98
PATCH_LIB("libGCloud.so", "0xC85187", "0E 70 A1 7A BB 32 E7 B6 DE 99 C1 99 F1 BA 14 D8"); // bytes_strength=3200 offset_strength=91
PATCH_LIB("libGCloud.so", "0x3827AE", "7A 29 5C 24 A5 23 7A A9 7E 4E 5A 49"); // bytes_strength=2400 offset_strength=97
PATCH_LIB("libGCloud.so", "0x5110E4", "2D 60 AA 31 10 56 06 A2 4C"); // bytes_strength=1800 offset_strength=95
PATCH_LIB("libGCloud.so", "0xACB2CA", "8A 81 51 3E 80 CB 80 DB 88 F1"); // bytes_strength=2000 offset_strength=100
PATCH_LIB("libGCloud.so", "0x13A3C5", "97 7F 12 E5 85 B1 EE 0A FB A7 D4 D8 03 C1 41 D1"); // bytes_strength=3200 offset_strength=98
PATCH_LIB("libGCloud.so", "0x6A966F", "A9 7C 4E 59 8D 14 DF 51 39 BB 65 76 BE F1 62 0A"); // bytes_strength=3200 offset_strength=99
PATCH_LIB("libGCloud.so", "0x867C66", "DD 43 76 21 10 92 7C 97 68 D5 52 D3 47 8D"); // bytes_strength=2800 offset_strength=91
PATCH_LIB("libGCloud.so", "0xC78657", "4D 59 1D 0E DC 0E 2C 6C 2C 2B 1A 3D A8"); // bytes_strength=2600 offset_strength=96
PATCH_LIB("libGCloud.so", "0x9B0DEA", "67 AB 38 F7 79 68 E3 8D 51 5F C2 BE DA D1 59"); // bytes_strength=3000 offset_strength=95
PATCH_LIB("libGCloud.so", "0xD08E50", "BA DF E8 3D 9A E7 7B 05 64 ED B9 B0 9B"); // bytes_strength=2600 offset_strength=97
PATCH_LIB("libGCloud.so", "0xD666CF", "80 E4 99 D9 BA 83 A6 71 C2 73 9C 7C 72 5F AD 9C"); // bytes_strength=3200 offset_strength=96
PATCH_LIB("libGCloud.so", "0x775D24", "95 D5 87 5B 47 7B 40 CE 03 26 92 1D BF E9 51"); // bytes_strength=3000 offset_strength=91
PATCH_LIB("libGCloud.so", "0x28B02A", "BB E9 A0 A8 53 6B CF 28 64 D5 DB 6C 0E"); // bytes_strength=2600 offset_strength=95
PATCH_LIB("libGCloud.so", "0xD366F6", "DB E5 C7 4D 62 BA ED 25 4B BC 09 F5 18 EF"); // bytes_strength=2800 offset_strength=93
PATCH_LIB("libGCloud.so", "0xB48EEB", "0F D4 D5 AA EB 71 16 B2 EE B6"); // bytes_strength=2000 offset_strength=100
PATCH_LIB("libGCloud.so", "0xE3B6DA", "FE BB D4 E8 A3 84 EF 19 80"); // bytes_strength=1800 offset_strength=94
PATCH_LIB("libGCloud.so", "0xD88DDF", "AD 4B 57 9D EF 47 0B CB 40 9A ED"); // bytes_strength=2200 offset_strength=95
PATCH_LIB("libGCloud.so", "0x898DA0", "EB 20 14 11 9B 50 51 EE F7 3E E1 6F 0B 40"); // bytes_strength=2800 offset_strength=94
PATCH_LIB("libGCloud.so", "0x3339C2", "83 19 13 BC A4 CE DC B5 15 00 10 DC B7"); // bytes_strength=2600 offset_strength=95
PATCH_LIB("libGCloud.so", "0xECC5E0", "C5 CF BC AB 40 E2 F0 59 07 EE F8 4E 3E C6 0A 5E"); // bytes_strength=3200 offset_strength=95
PATCH_LIB("libGCloud.so", "0xA5F2AA", "12 68 F4 31 BE EF 71 CB E1 CF 6C 68"); // bytes_strength=2400 offset_strength=93
PATCH_LIB("libGCloud.so", "0x7B7D21", "DD B6 0E 82 69 A6 8C DE 87 09 22"); // bytes_strength=2200 offset_strength=94
PATCH_LIB("libGCloud.so", "0x7AA1E1", "70 FF 9A D3 6B F3 4A 63 AE"); // bytes_strength=1800 offset_strength=92
PATCH_LIB("libGCloud.so", "0x486E1F", "9B 3A 62 58 A1 8E AC D4 EA A4 D1 89 61"); // bytes_strength=2600 offset_strength=90
PATCH_LIB("libGCloud.so", "0x125C53", "15 E4 36 18 7D 3D 20 55 F5 D1"); // bytes_strength=2000 offset_strength=94
PATCH_LIB("libGCloud.so", "0x9E2202", "D4 E8 04 24 BF EC 67 B7 49 FF 88 01 66 B9 FF"); // bytes_strength=3000 offset_strength=92
PATCH_LIB("libGCloud.so", "0x600658", "10 F8 86 73 66 1C 82 1F 11 73 C1 21 16"); // bytes_strength=2600 offset_strength=96
PATCH_LIB("libGCloud.so", "0x7EB6D1", "D3 BA 78 45 03 8E 03 22 67 7D 3D FC"); // bytes_strength=2400 offset_strength=97
PATCH_LIB("libGCloud.so", "0x565CBB", "B3 CF 96 70 99 80 9A B5 F9 61 C3 D6 46 BA 4A C9"); // bytes_strength=3200 offset_strength=94
PATCH_LIB("libGCloud.so", "0xD60797", "8F B6 C7 05 90 41 90 C4 57 43 3C 37 78 A8 C6 54"); // bytes_strength=3200 offset_strength=100
PATCH_LIB("libGCloud.so", "0xEC96F8", "43 B3 3E 0F EE F6 82 D6 9A 0A"); // bytes_strength=2000 offset_strength=99
PATCH_LIB("libGCloud.so", "0xD92AC9", "38 85 88 39 CA 3D 51 A5 1E 99 54 A5 49 7E 37 99"); // bytes_strength=3200 offset_strength=92
PATCH_LIB("libGCloud.so", "0x638846", "13 D8 A3 DB 9B E9 C4 C5 3D 6F 44 15 D5 A2 7F AB"); // bytes_strength=3200 offset_strength=95
PATCH_LIB("libGCloud.so", "0x449335", "3D BB 63 91 FA F3 57 1E B0 82 94 67 50 F7 C5"); // bytes_strength=3000 offset_strength=90
PATCH_LIB("libGCloud.so", "0x84A592", "AD 6D 4F 45 7D D2 84 FF 0A 9E 5F B6"); // bytes_strength=2400 offset_strength=91
PATCH_LIB("libGCloud.so", "0xA95EE3", "CA 8D DC F6 E2 FD AB 68 1B"); // bytes_strength=1800 offset_strength=92
PATCH_LIB("libGCloud.so", "0x911BAD", "D5 1B F3 32 FD C7 04 7C 36 03 D8 77 B3"); // bytes_strength=2600 offset_strength=97
PATCH_LIB("libGCloud.so", "0x4EE164", "D4 C5 BD 7E 01 11 32 17 F0 A4 9A 96 93"); // bytes_strength=2600 offset_strength=97
PATCH_LIB("libGCloud.so", "0xFF410F", "55 08 EB 4A 0A 20 B5 6A F1 9E CC 73"); // bytes_strength=2400 offset_strength=100
PATCH_LIB("libGCloud.so", "0xA9C87A", "1E 5F 52 59 EB EC 38 AE 25"); // bytes_strength=1800 offset_strength=97
PATCH_LIB("libGCloud.so", "0x390D6C", "FF 3D 0E 83 0B C0 EE 55 6F 86 AF 76 AE 7E DF 8D"); // bytes_strength=3200 offset_strength=96
PATCH_LIB("libGCloud.so", "0x798898", "24 04 10 DA 2C 67 28 7A A1 60 C9"); // bytes_strength=2200 offset_strength=100
PATCH_LIB("libGCloud.so", "0x2A79F8", "98 69 6E EC A5 C2 A5 1F 22 A2 2D 47"); // bytes_strength=2400 offset_strength=93
PATCH_LIB("libGCloud.so", "0xB8DB0D", "5D 4C C0 74 C3 93 15 F0 7C EE 1A D4 8C 3B"); // bytes_strength=2800 offset_strength=91
PATCH_LIB("libGCloud.so", "0xF02697", "8C A2 BF 71 70 D8 28 7E F8 B3 BD 7D 86 EF 30"); // bytes_strength=3000 offset_strength=100
PATCH_LIB("libGCloud.so", "0x4DF321", "F6 4C A3 58 4C 85 F4 81 0A 5C F3 1B 0C"); // bytes_strength=2600 offset_strength=91
PATCH_LIB("libGCloud.so", "0x4A2B81", "E1 3E FB 55 6F 59 F9 8F 30 62 FE EC"); // bytes_strength=2400 offset_strength=92
PATCH_LIB("libGCloud.so", "0x9F0E67", "2D 03 E3 8A 8B D0 64 51 8F 41 ED"); // bytes_strength=2200 offset_strength=92
PATCH_LIB("libGCloud.so", "0x9E9CCE", "A8 25 75 79 C9 31 66 E3 E7 4B 8C 99 1F AC"); // bytes_strength=2800 offset_strength=100
PATCH_LIB("libGCloud.so", "0xCE2E3B", "CB C9 53 EC 9C 22 20 4F B4"); // bytes_strength=1800 offset_strength=96
PATCH_LIB("libGCloud.so", "0xA363B6", "7E D3 91 91 87 81 E7 64 63"); // bytes_strength=1800 offset_strength=93
PATCH_LIB("libGCloud.so", "0xEE9EA9", "2F 16 3F 1E 98 C0 A1 53 F2 60 28 ED"); // bytes_strength=2400 offset_strength=100
PATCH_LIB("libGCloud.so", "0x796DB3", "DF F3 CE 25 F8 80 69 A8 72 CA"); // bytes_strength=2000 offset_strength=100
PATCH_LIB("libGCloud.so", "0x9D5403", "87 40 75 75 08 0D B6 27 83 5C 3C E8 23 95 DE"); // bytes_strength=3000 offset_strength=94
PATCH_LIB("libGCloud.so", "0x77907A", "4B 16 7C AF 82 60 B1 FE 8B F4 0E F9"); // bytes_strength=2400 offset_strength=92
PATCH_LIB("libGCloud.so", "0xDFF99C", "B4 49 D1 1D 86 88 32 95 05 11 18 1D 96 9F"); // bytes_strength=2800 offset_strength=95
PATCH_LIB("libGCloud.so", "0xF242AC", "E6 2B 70 3C 7C 75 E2 6F 0D 51 18 09 27 64"); // bytes_strength=2800 offset_strength=90
PATCH_LIB("libGCloud.so", "0xA60A36", "F1 04 39 E4 8A B2 A9 F8 3E"); // bytes_strength=1800 offset_strength=100
PATCH_LIB("libGCloud.so", "0xA947CB", "A3 59 F2 B5 11 10 24 F9 84 7D D7 00"); // bytes_strength=2400 offset_strength=95
PATCH_LIB("libGCloud.so", "0xEE8649", "A2 62 8B A5 6B EC 82 68 6C B1 B6 D3 46 15 59 4E"); // bytes_strength=3200 offset_strength=95
PATCH_LIB("libGCloud.so", "0x40B2B0", "95 57 56 AD 73 E0 BD F5 F4 A2 28 C8"); // bytes_strength=2400 offset_strength=99
PATCH_LIB("libGCloud.so", "0xD8BA88", "2D DF EE FE 91 8C 7A 78 84 66 CE 5F CD A5 CD 3B"); // bytes_strength=3200 offset_strength=92
PATCH_LIB("libGCloud.so", "0xE7BEC7", "C2 C8 64 6D 03 48 36 46"); // bytes_strength=1600 offset_strength=91
PATCH_LIB("libGCloud.so", "0x3B1614", "CF A4 14 B4 75 28 D1 B8 B5 53 BC 2E"); // bytes_strength=2400 offset_strength=97
PATCH_LIB("libGCloud.so", "0x9051BF", "FD AA 9E 35 E9 25 17 2A A6 99 F2 EB 6B EC"); // bytes_strength=2800 offset_strength=95
PATCH_LIB("libGCloud.so", "0x5551B8", "F7 5E DE 2B 59 45 5A C3 30 3F 20 F5 64"); // bytes_strength=2600 offset_strength=93
PATCH_LIB("libGCloud.so", "0x4F6FA4", "93 4B 2D 9E 3A 4B 91 AB 9E C6"); // bytes_strength=2000 offset_strength=90
PATCH_LIB("libGCloud.so", "0x43196F", "01 C9 B2 37 8C 41 FC B1 69 4C E0 C5"); // bytes_strength=2400 offset_strength=99
PATCH_LIB("libGCloud.so", "0xAE081F", "9A 78 7F 73 CB C7 FA D5 C0 12 63 36 4A 7B D0 B0"); // bytes_strength=3200 offset_strength=100
PATCH_LIB("libGCloud.so", "0x732330", "F7 FE 5E 64 7F AE CE 7D 61 7D 25 26 0A"); // bytes_strength=2600 offset_strength=97
PATCH_LIB("libGCloud.so", "0xE3F83F", "3C FA 17 14 C1 51 79 A2 06"); // bytes_strength=1800 offset_strength=93
PATCH_LIB("libGCloud.so", "0xAB30A7", "A3 17 6F 50 2B 1F C4 FB 7D 0A 9D"); // bytes_strength=2200 offset_strength=97
PATCH_LIB("libGCloud.so", "0xACFC4B", "F4 A7 24 07 13 29 11 34 1D 7A 95"); // bytes_strength=2200 offset_strength=98
PATCH_LIB("libGCloud.so", "0x8943ED", "A0 5A C2 3C A7 04 0F 6D 47 76 D3 92 9E BE"); // bytes_strength=2800 offset_strength=91
PATCH_LIB("libGCloud.so", "0x1F2E8B", "23 B5 13 17 EA F1 C0 FD 71 59 65 0A"); // bytes_strength=2400 offset_strength=99
PATCH_LIB("libGCloud.so", "0x3E49B5", "FA AA 6C 5A 8B 03 26 EA 5C 3A 2A 7A"); // bytes_strength=2400 offset_strength=91


PATCH_LIB("libanogs.so", "0x853998", "D9 97 6B 66 3F 5D A0 C2 3C E4 81 FA 8B 8A"); // bytes_strength=2800 offset_strength=100
PATCH_LIB("libanogs.so", "0x676BCC", "28 A6 7F E5 5E 75 8E 5A 8A F5 EF EE"); // bytes_strength=2400 offset_strength=91
PATCH_LIB("libanogs.so", "0x222F94", "F1 53 AE 6C 0D 41 A3 A1 5F 07 CF"); // bytes_strength=2200 offset_strength=95
PATCH_LIB("libanogs.so", "0xBB6EE8", "4D 53 4C 25 C3 4A 58 89 53 A4"); // bytes_strength=2000 offset_strength=90
PATCH_LIB("libanogs.so", "0xEA682A", "8C DB C9 7A 6B 37 72 C2 0B 4C 79 7B"); // bytes_strength=2400 offset_strength=90
PATCH_LIB("libanogs.so", "0x1DF116", "41 DE 6A E0 12 95 28 78 18 D0 A4 C8"); // bytes_strength=2400 offset_strength=95
PATCH_LIB("libanogs.so", "0x1CDD8B", "D1 92 36 3F 57 6A 53 B3 20 C3 3B"); // bytes_strength=2200 offset_strength=100
PATCH_LIB("libanogs.so", "0xAE2775", "6B 4D C7 87 98 0E 5A 34"); // bytes_strength=1600 offset_strength=98
PATCH_LIB("libanogs.so", "0x3DE221", "DF 94 C3 51 EF FB 6E 6D"); // bytes_strength=1600 offset_strength=94
PATCH_LIB("libanogs.so", "0xB09833", "E7 57 BD E1 D9 92 F1 50 72 58 EB 46 35 D5 BB"); // bytes_strength=3000 offset_strength=90
PATCH_LIB("libanogs.so", "0xEC1A12", "7D FB D4 CF C5 2D 4B D2 98 D0 C7 EE"); // bytes_strength=2400 offset_strength=91
PATCH_LIB("libanogs.so", "0xE4316D", "D4 79 9D D4 8F 82 17 3E 40 BA 7F 87 E7 5C B9 4B"); // bytes_strength=3200 offset_strength=95
PATCH_LIB("libanogs.so", "0x2F00B2", "13 FA CA 60 77 BD FC E6 8A C8 A0 1A 1B"); // bytes_strength=2600 offset_strength=96
PATCH_LIB("libanogs.so", "0xC48DDC", "EF 16 D5 04 7B D4 18 68 1A 6B D4 C9 37 45 66 30"); // bytes_strength=3200 offset_strength=98
PATCH_LIB("libanogs.so", "0x14BC69", "F5 13 5B 34 24 B9 BE 5A 89 67 45 60 24 70 DD"); // bytes_strength=3000 offset_strength=98
PATCH_LIB("libanogs.so", "0xF7DDF5", "2D 7C 61 04 0D AF 57 9B 92 F2 CD 8D D3 BA 68 14"); // bytes_strength=3200 offset_strength=99
PATCH_LIB("libanogs.so", "0xE6B8A3", "F3 30 19 45 3F FA 2D 75 39 89 E1 50 58 1F E7"); // bytes_strength=3000 offset_strength=95
PATCH_LIB("libanogs.so", "0x9363C0", "42 1C 10 A3 B3 28 53 C7 A7 43 5F CE B5 5C 98"); // bytes_strength=3000 offset_strength=97
PATCH_LIB("libanogs.so", "0x407158", "2B DD 81 1B 9B E7 55 60 D9 F7 5C"); // bytes_strength=2200 offset_strength=93
PATCH_LIB("libanogs.so", "0x1EED5E", "FC 0F C8 9F C0 9E 49 BE 6F 26 F3 70"); // bytes_strength=2400 offset_strength=99
PATCH_LIB("libanogs.so", "0x3CA2B5", "DC A4 2B 84 D2 AE 18 72 F4 8D"); // bytes_strength=2000 offset_strength=98
PATCH_LIB("libanogs.so", "0xF4479F", "95 4F C5 AE BB 37 B8 85 58 C0 C9 54"); // bytes_strength=2400 offset_strength=92
PATCH_LIB("libanogs.so", "0x8AA9D2", "91 BC 50 67 98 6B 86 BE 50 3A C5 77 79"); // bytes_strength=2600 offset_strength=96
PATCH_LIB("libanogs.so", "0x262AE6", "1F AB 0D F4 F9 B4 3D AE 34 93 56 9B"); // bytes_strength=2400 offset_strength=99
PATCH_LIB("libanogs.so", "0xE1A031", "FB 63 58 8D A4 79 00 A6 7A CD DD 80 CD"); // bytes_strength=2600 offset_strength=93
PATCH_LIB("libanogs.so", "0x909EFA", "55 8D F1 90 29 9E A0 05 8A 5D"); // bytes_strength=2000 offset_strength=99
PATCH_LIB("libanogs.so", "0x1EFBF3", "7A C6 54 5C 28 34 F5 5F 2A 86 3A"); // bytes_strength=2200 offset_strength=92
PATCH_LIB("libanogs.so", "0x3E21F9", "AD A1 EF E7 C4 80 C6 60 EE 26 42 D0 E4 91 B6"); // bytes_strength=3000 offset_strength=92
PATCH_LIB("libanogs.so", "0xA85760", "9A 41 6F BA D5 FF 2A 80"); // bytes_strength=1600 offset_strength=95
PATCH_LIB("libanogs.so", "0x9B593D", "B2 8A D2 5F 8B B2 F7 18 D4 1A 61 56 6B EA 0C DF"); // bytes_strength=3200 offset_strength=95
PATCH_LIB("libanogs.so", "0xDD9348", "7E 30 76 9C FE AB FB FD C9 10 49"); // bytes_strength=2200 offset_strength=96
PATCH_LIB("libanogs.so", "0x8802B4", "24 14 33 D0 5B 4C 62 DE 60 2E 0E"); // bytes_strength=2200 offset_strength=96
PATCH_LIB("libanogs.so", "0x43888A", "F5 EA BB 29 06 3B 36 9D 6B"); // bytes_strength=1800 offset_strength=96
PATCH_LIB("libanogs.so", "0x84DC5D", "98 3C F3 D3 F8 54 56 C4 AF D9 41 71 68 44 DA ED"); // bytes_strength=3200 offset_strength=100
PATCH_LIB("libanogs.so", "0xF13C8D", "5E F3 13 2F 6A 49 0D 0D 07 C3 C7 D6 55 7F E6"); // bytes_strength=3000 offset_strength=98
PATCH_LIB("libanogs.so", "0x9D83E1", "DB 1E 9A 49 65 4C 9A F8 09 40 2E A6 B7 B0"); // bytes_strength=2800 offset_strength=93
PATCH_LIB("libanogs.so", "0x9385C8", "ED B0 0F 72 B5 DF 29 5C F1 18 4D 9D 57 4F 8C"); // bytes_strength=3000 offset_strength=94
PATCH_LIB("libanogs.so", "0xE7D36F", "13 2D 3D 8D A5 F1 33 FB 93 0E B4 F6 23 86 91"); // bytes_strength=3000 offset_strength=98
PATCH_LIB("libanogs.so", "0x6DA649", "89 6F C6 D5 9C 56 4E BF C1 40 82 E3 28"); // bytes_strength=2600 offset_strength=95
PATCH_LIB("libanogs.so", "0xB9F9DA", "C8 97 40 A8 9E B4 13 F7 09 A6 82 F0 99 22 6C"); // bytes_strength=3000 offset_strength=92
PATCH_LIB("libanogs.so", "0x927BE3", "C3 6E CE F9 11 07 04 3E C5 34 7D"); // bytes_strength=2200 offset_strength=96
PATCH_LIB("libanogs.so", "0xF07DC6", "50 BD 7D 0F 50 ED 92 CF 23 73 F2 A8 CC 25 10 14"); // bytes_strength=3200 offset_strength=98
PATCH_LIB("libanogs.so", "0x2AAA92", "5F 77 B4 70 8D 9B A9 40 8C 0A FA FE C1"); // bytes_strength=2600 offset_strength=95
PATCH_LIB("libanogs.so", "0xA62B8E", "E9 A1 44 B7 62 C4 4C 18 EA 30"); // bytes_strength=2000 offset_strength=92
PATCH_LIB("libanogs.so", "0x44DFF8", "03 56 4D E8 21 94 31 92 20 7D"); // bytes_strength=2000 offset_strength=90
PATCH_LIB("libanogs.so", "0x768A40", "1B 0B 56 29 D9 9E B2 96 E8 4D EF 6E"); // bytes_strength=2400 offset_strength=90
PATCH_LIB("libanogs.so", "0xDCF445", "EF E1 97 D9 C3 B6 91 06 A7 6E 7F 09 21 92 82 98"); // bytes_strength=3200 offset_strength=100
PATCH_LIB("libanogs.so", "0xE6B01D", "03 75 49 58 D4 31 1F 1B CC E8 BD 10 02 D2 46 59"); // bytes_strength=3200 offset_strength=100
PATCH_LIB("libanogs.so", "0x728C9D", "B5 4A 71 DE 2C 9F E8 FB 00 3F AE C7 DD 24 20"); // bytes_strength=3000 offset_strength=99
PATCH_LIB("libanogs.so", "0x51A6E3", "46 9B C9 E9 CA 30 86 5D D6 4F"); // bytes_strength=2000 offset_strength=97
PATCH_LIB("libanogs.so", "0x171ED2", "FA B5 94 FB 57 83 4A 48 67 FB 84 1A C1"); // bytes_strength=2600 offset_strength=95
PATCH_LIB("libanogs.so", "0x5B1C02", "E3 BE CD 64 E8 68 29 77 98"); // bytes_strength=1800 offset_strength=91
PATCH_LIB("libanogs.so", "0x673C13", "E8 3E F4 0B B9 34 F4 13 66 0C"); // bytes_strength=2000 offset_strength=99
PATCH_LIB("libanogs.so", "0x3F4E62", "11 B9 70 FB 44 FD 6A D8 1A 1B E1 BA 7F D2 39"); // bytes_strength=3000 offset_strength=97
PATCH_LIB("libanogs.so", "0xC14907", "92 68 06 E3 77 89 B5 64 66 3A 26 51 5A"); // bytes_strength=2600 offset_strength=94
PATCH_LIB("libanogs.so", "0x917139", "E6 B7 D7 27 AA D4 59 F6 25 8A B3 64 E3 A2 94"); // bytes_strength=3000 offset_strength=96
PATCH_LIB("libanogs.so", "0xABC399", "FC CF 3A 81 F5 18 BE 9B 4B 5F 72 C9 E0 60"); // bytes_strength=2800 offset_strength=92
PATCH_LIB("libanogs.so", "0xCBB4EC", "A9 36 A2 27 3A AC 66 84 76 14 DD F4 49 12"); // bytes_strength=2800 offset_strength=91
PATCH_LIB("libanogs.so", "0xF26915", "4F AA CC 98 02 82 37 B4 60"); // bytes_strength=1800 offset_strength=90
PATCH_LIB("libanogs.so", "0x30C164", "21 78 DE 28 B5 D5 78 3B BF 6E DA"); // bytes_strength=2200 offset_strength=95
PATCH_LIB("libanogs.so", "0x9C294D", "BB A0 C2 EB 25 0E 0E 73 AD 43 F4 74"); // bytes_strength=2400 offset_strength=94
PATCH_LIB("libanogs.so", "0x884672", "73 70 80 7C 23 D1 4F BD 73 B2 15 87"); // bytes_strength=2400 offset_strength=94
PATCH_LIB("libanogs.so", "0x5BAD96", "6C B1 32 30 B6 0B 0E C1 EB 59 D3"); // bytes_strength=2200 offset_strength=90
PATCH_LIB("libanogs.so", "0x2CAEAB", "1A 3B 8C 8F 22 A0 2D 5F E3 6F 6D 49 95 73"); // bytes_strength=2800 offset_strength=98
PATCH_LIB("libanogs.so", "0x1129D5", "37 FE 94 C7 EE E6 6F 01 3C 06 D8 64"); // bytes_strength=2400 offset_strength=99
PATCH_LIB("libanogs.so", "0x6D83AB", "85 AF F8 B1 CD 87 52 1E 4D CC"); // bytes_strength=2000 offset_strength=99
PATCH_LIB("libanogs.so", "0x7E4FE3", "0E 79 9A 31 5B 11 7B B0 97 37 59 31 03"); // bytes_strength=2600 offset_strength=100
PATCH_LIB("libanogs.so", "0xC58183", "8A 5E E3 98 33 F7 7F 0E BA AE"); // bytes_strength=2000 offset_strength=100
PATCH_LIB("libanogs.so", "0x867E3F", "7C 3E 84 29 37 E3 93 17 52 35 A2 36 03 26 4B"); // bytes_strength=3000 offset_strength=100
PATCH_LIB("libanogs.so", "0x2AEAEF", "4D 37 7A F7 6A B8 18 89 4F EE A7 AD 96"); // bytes_strength=2600 offset_strength=96
PATCH_LIB("libanogs.so", "0xA25414", "FB 8E 64 C1 B3 AA A8 ED FF 3A ED"); // bytes_strength=2200 offset_strength=97
PATCH_LIB("libanogs.so", "0x4904DB", "C6 ED AF 9A 12 C3 9E D6 06 E3 9D"); // bytes_strength=2200 offset_strength=93
PATCH_LIB("libanogs.so", "0x4C10B9", "88 D4 CD 55 97 E3 09 AD DE 03 BE"); // bytes_strength=2200 offset_strength=97
PATCH_LIB("libanogs.so", "0xA8DEDD", "8C AE 73 81 F2 88 1E 9B 77 0A AB 47"); // bytes_strength=2400 offset_strength=95
PATCH_LIB("libanogs.so", "0x71841A", "F4 F9 68 58 2B B6 AF BE 11 92"); // bytes_strength=2000 offset_strength=95
PATCH_LIB("libanogs.so", "0x306493", "C4 8B 72 8E 4F 81 73 63 60 27 1A 49 54 31 9E"); // bytes_strength=3000 offset_strength=90
PATCH_LIB("libanogs.so", "0xAF3987", "F8 96 72 06 A9 51 4D 88 FD 2C"); // bytes_strength=2000 offset_strength=93
PATCH_LIB("libanogs.so", "0xC17293", "A7 0A 7A 29 F9 E7 60 EC BE 2D 60 4F 3C AE 2D"); // bytes_strength=3000 offset_strength=94
PATCH_LIB("libanogs.so", "0x599638", "7F 11 70 DE 5A 2F B6 AB 83 7D 10 2D 22"); // bytes_strength=2600 offset_strength=92
PATCH_LIB("libanogs.so", "0x39459A", "B9 34 AA 15 F0 AE B1 78"); // bytes_strength=1600 offset_strength=93
PATCH_LIB("libanogs.so", "0xF4250B", "C1 67 4D A8 8B AB FC A1 15 1D FB"); // bytes_strength=2200 offset_strength=90
PATCH_LIB("libanogs.so", "0x1457B1", "85 6C EA CD E5 59 F6 B8 E0"); // bytes_strength=1800 offset_strength=90
PATCH_LIB("libanogs.so", "0xDE36F0", "36 0E 73 80 F6 EE 49 4D 8C 0E"); // bytes_strength=2000 offset_strength=92
PATCH_LIB("libanogs.so", "0xE83DE4", "B0 8D 4F 26 2D 9A 8D FF"); // bytes_strength=1600 offset_strength=90
PATCH_LIB("libanogs.so", "0x4D015F", "A9 12 F3 0E 89 60 0E 6D"); // bytes_strength=1600 offset_strength=92
PATCH_LIB("libanogs.so", "0x51E434", "04 D1 97 DD 22 8A 36 C7 3B 2D A7 7E EC AE E0 C9"); // bytes_strength=3200 offset_strength=95
PATCH_LIB("libanogs.so", "0x3D9CFC", "8C 74 62 6B 1C EF 95 E5 13"); // bytes_strength=1800 offset_strength=90
PATCH_LIB("libanogs.so", "0xB822AB", "1C 96 48 4B 6B 1A 07 FC BE 50 DA"); // bytes_strength=2200 offset_strength=95
PATCH_LIB("libanogs.so", "0xAE1D67", "58 BA 07 49 13 C7 BB E9 4B"); // bytes_strength=1800 offset_strength=92
PATCH_LIB("libanogs.so", "0x46507F", "6A E1 04 35 EE E7 DC 43 A5 9D 94 81 C8 F7"); // bytes_strength=2800 offset_strength=97
PATCH_LIB("libanogs.so", "0x72E512", "EA D2 74 10 69 EB 13 56"); // bytes_strength=1600 offset_strength=96
PATCH_LIB("libanogs.so", "0xA2F68C", "67 2A 00 44 36 31 9F 3B 2D E2 A6 43 3F 29"); // bytes_strength=2800 offset_strength=91
PATCH_LIB("libanogs.so", "0x49B090", "D1 D0 42 C1 A2 CA D0 94 A1 48 A0"); // bytes_strength=2200 offset_strength=92
PATCH_LIB("libanogs.so", "0x491107", "81 CB F3 B3 00 B2 84 5C 5E"); // bytes_strength=1800 offset_strength=97
PATCH_LIB("libanogs.so", "0x4D3C15", "7D 1D 5F DE 25 BF DA B4 20 3A 4F 25 DD 27"); // bytes_strength=2800 offset_strength=92
PATCH_LIB("libanogs.so", "0x409561", "B3 C2 46 ED 23 6B 52 41 71 92 6C 83 CB 7A DD CC"); // bytes_strength=3200 offset_strength=99
PATCH_LIB("libanogs.so", "0x92D379", "9D 83 93 45 F0 C2 8C 85"); // bytes_strength=1600 offset_strength=93
PATCH_LIB("libanogs.so", "0xA471B3", "CD 3B 35 D8 FE 87 43 30 36 84 B7 AC FA 12 AD"); // bytes_strength=3000 offset_strength=97
PATCH_LIB("libanogs.so", "0xBB6985", "B9 8E 37 7C ED D2 7F 9F 40 2E 19 BF 3C 3D F8 52"); // bytes_strength=3200 offset_strength=91
PATCH_LIB("libanogs.so", "0x50E949", "AF 04 43 82 37 7B 37 26 0B B8"); // bytes_strength=2000 offset_strength=96
PATCH_LIB("libanogs.so", "0x10EA02", "0E 56 CB 1D 84 29 38 56 5E E3 0C 2A D7 0D"); // bytes_strength=2800 offset_strength=100
PATCH_LIB("libanogs.so", "0xD7CD53", "6C B3 26 33 66 98 50 47 75"); // bytes_strength=1800 offset_strength=94
PATCH_LIB("libanogs.so", "0x80BCA9", "2E 8A D9 73 39 69 35 6E 96 64 EA 7C 31 9A DE"); // bytes_strength=3000 offset_strength=95
PATCH_LIB("libanogs.so", "0x5EE5DE", "44 3A 7E 2B 4A 02 DE CE 3E"); // bytes_strength=1800 offset_strength=93
PATCH_LIB("libanogs.so", "0x3BE69D", "60 0C 86 F5 8F 69 F4 F2 98 0E B2 25 D2"); // bytes_strength=2600 offset_strength=90
PATCH_LIB("libanogs.so", "0x4FB27F", "39 18 A3 B2 E2 79 8C 0F 6C AB EC A4 EC 09"); // bytes_strength=2800 offset_strength=100
PATCH_LIB("libanogs.so", "0xCC293A", "E3 1C 34 B2 A1 55 65 36 3B 0C 7A 3C 09 A4 B7"); // bytes_strength=3000 offset_strength=96
PATCH_LIB("libanogs.so", "0xE9A458", "A7 54 F7 51 DA F5 BA 31 4A 18 34"); // bytes_strength=2200 offset_strength=95
PATCH_LIB("libanogs.so", "0xD71E84", "49 8D 6B 64 B8 B7 93 06 55 8C 8A"); // bytes_strength=2200 offset_strength=91
PATCH_LIB("libanogs.so", "0x3EEC9B", "52 0C 8B D5 17 32 8E 8C 94 6B 0A 1A E9 EC 8E"); // bytes_strength=3000 offset_strength=93
PATCH_LIB("libanogs.so", "0x41F68C", "AA 4C 51 6D F3 D7 11 63 F1 1F DC 63"); // bytes_strength=2400 offset_strength=97
PATCH_LIB("libanogs.so", "0xB19DE0", "9D B5 27 EF BD AF 97 B6 85 06"); // bytes_strength=2000 offset_strength=91
PATCH_LIB("libanogs.so", "0x374F7D", "73 F4 D1 F3 F0 03 23 92 F7 C6"); // bytes_strength=2000 offset_strength=100
PATCH_LIB("libanogs.so", "0xD65428", "1E AA 0E B2 02 3C 46 CC 81"); // bytes_strength=1800 offset_strength=91
PATCH_LIB("libanogs.so", "0x80A342", "6F 31 BB 21 6A 61 16 37 BA"); // bytes_strength=1800 offset_strength=94
PATCH_LIB("libanogs.so", "0xA1B5B1", "81 75 94 DE BC C0 57 CF 66"); // bytes_strength=1800 offset_strength=91
PATCH_LIB("libanogs.so", "0x2E6AF3", "A3 D7 C1 E9 11 DA 6E 47 FE BD 04 72 BA 27 F3 17"); // bytes_strength=3200 offset_strength=93
PATCH_LIB("libanogs.so", "0xE5C08D", "15 3E 51 A7 55 D5 C9 2B 8E A8 08 1F"); // bytes_strength=2400 offset_strength=92
PATCH_LIB("libanogs.so", "0x880BD2", "A5 DE 9F 34 EE 29 3F 71 34 13 92 80 A0 9D 2E 43"); // bytes_strength=3200 offset_strength=91
PATCH_LIB("libanogs.so", "0xC0C23D", "3B 42 E1 5B 1E 5A CC DD"); // bytes_strength=1600 offset_strength=98
PATCH_LIB("libanogs.so", "0x219DA9", "30 1F D5 42 17 E1 51 32 5F CF E3 96"); // bytes_strength=2400 offset_strength=98
PATCH_LIB("libanogs.so", "0x990A06", "0A D0 85 CE CD A5 EF 0F 39 2B DC F5"); // bytes_strength=2400 offset_strength=98
PATCH_LIB("libanogs.so", "0x84AC39", "23 30 F0 17 05 0F 5A 65"); // bytes_strength=1600 offset_strength=100
PATCH_LIB("libanogs.so", "0x479969", "EF E7 75 ED 7C 42 69 87 A8"); // bytes_strength=1800 offset_strength=93
PATCH_LIB("libanogs.so", "0xDA6886", "A2 65 51 BC 8F A4 77 60 D2 94 32 08 3D 16"); // bytes_strength=2800 offset_strength=99
PATCH_LIB("libanogs.so", "0xA6F219", "22 31 42 86 38 47 0F 86 D3 5B CA FC 35 5F FF"); // bytes_strength=3000 offset_strength=96
PATCH_LIB("libanogs.so", "0x2D9A2A", "68 66 33 5A 4C 35 A5 BC C2 0C 57 10 06 05"); // bytes_strength=2800 offset_strength=99
PATCH_LIB("libanogs.so", "0x37AFDB", "2A 8F C6 27 C3 CD 63 8F 60 D5 CB C8 8C BE"); // bytes_strength=2800 offset_strength=92
PATCH_LIB("libanogs.so", "0x3C2F55", "62 76 DE 99 86 2C 88 19 5A BD 67"); // bytes_strength=2200 offset_strength=97
PATCH_LIB("libanogs.so", "0x38A431", "34 4A 0A D8 40 0C 89 58"); // bytes_strength=1600 offset_strength=94
PATCH_LIB("libanogs.so", "0x8F6012", "60 92 5C E1 4F 3E 00 CA 44 EF DE 0A DD 34 3E B3"); // bytes_strength=3200 offset_strength=99
PATCH_LIB("libanogs.so", "0x799FD9", "2C 53 3A 66 F0 FB DC CD DD 16 34 A0"); // bytes_strength=2400 offset_strength=98
PATCH_LIB("libanogs.so", "0x7EF2ED", "9E CD 49 88 F2 EB E5 AE 7B 28 0D 14 20 25 26"); // bytes_strength=3000 offset_strength=96
PATCH_LIB("libanogs.so", "0xC15E45", "62 C7 09 EC 07 5C 30 13 F0 B3"); // bytes_strength=2000 offset_strength=97
PATCH_LIB("libanogs.so", "0xD5A231", "A6 A7 BD 23 4C 27 FF 23 E6 1F 53 C9 03"); // bytes_strength=2600 offset_strength=97
PATCH_LIB("libanogs.so", "0x13BEA1", "D0 D5 8D AE 6C 02 13 D2 AE A5 F9"); // bytes_strength=2200 offset_strength=90
PATCH_LIB("libanogs.so", "0x815EE1", "AA 9F 73 B8 48 52 38 4C 51"); // bytes_strength=1800 offset_strength=92
PATCH_LIB("libanogs.so", "0x79E1C0", "21 3E 53 EE D1 4E 74 D0 29 D9 ED 97 32 4C 55 D7"); // bytes_strength=3200 offset_strength=91
PATCH_LIB("libanogs.so", "0x8E3FFD", "ED 81 0B 47 76 F9 C3 F5 54 C7 3C 24 94 EF"); // bytes_strength=2800 offset_strength=90
PATCH_LIB("libanogs.so", "0xE38BC7", "AF C6 15 6C AF A9 C1 C9 D1 8A 20 95 4B 8F"); // bytes_strength=2800 offset_strength=98
PATCH_LIB("libanogs.so", "0xFD29AC", "9F 6B 92 B6 77 77 BA 65 FE 1A 42 78 81 78 81"); // bytes_strength=3000 offset_strength=95
PATCH_LIB("libanogs.so", "0xB59FBC", "94 D4 F5 C7 B5 BE 7C B6 42 B8"); // bytes_strength=2000 offset_strength=91
PATCH_LIB("libanogs.so", "0x99DB33", "67 6E BB FB E6 68 1E E6 1A B1 EA 3E 97"); // bytes_strength=2600 offset_strength=93
PATCH_LIB("libanogs.so", "0xEBD46A", "B8 3E 6C D4 8C A2 20 E6 82 8C D0 97 9E 06"); // bytes_strength=2800 offset_strength=96
PATCH_LIB("libanogs.so", "0x494770", "88 8F B4 5D DF 61 46 E0 2E A2"); // bytes_strength=2000 offset_strength=90
PATCH_LIB("libanogs.so", "0x8BEA60", "A2 25 5E 16 CC 0A 50 8D 05 88 C9 56 C5 A7 35"); // bytes_strength=3000 offset_strength=93
PATCH_LIB("libanogs.so", "0x8929EF", "7E 2B E4 4D B4 D1 F3 03 49 EE CA"); // bytes_strength=2200 offset_strength=91
PATCH_LIB("libanogs.so", "0x9EF76D", "A7 90 B9 23 C2 C9 64 37 CF C4 D2"); // bytes_strength=2200 offset_strength=100
PATCH_LIB("libanogs.so", "0x9C2B9E", "D6 CA 3D 67 67 07 2C F5"); // bytes_strength=1600 offset_strength=100
PATCH_LIB("libanogs.so", "0xE5C617", "05 DD C8 21 DE 64 CA 3C 18 1B 3A 05 75 A7 60 08");
